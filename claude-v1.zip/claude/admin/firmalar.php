<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Admin kontrolü
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$db = getDB();

// Firmaları getir
$sql = "SELECT f.*, 
        (SELECT COUNT(*) FROM kullanicilar WHERE firma_id = f.id) as kullanici_sayisi,
        (SELECT COUNT(*) FROM sozlesmeler WHERE firma_id = f.id) as sozlesme_sayisi
        FROM firmalar f
        ORDER BY f.olusturma_tarihi DESC";
$stmt = $db->query($sql);
$firmalar = $stmt->fetchAll();

$page_title = 'Firmalar - Süper Admin';
$body_class = 'admin-theme';
?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<!-- Main Content -->
<div class="main-content">
    <div class="container-fluid">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 text-white">
            <h2 class="fw-bold mb-0"><i class="bi bi-building"></i> Firmalar</h2>
            <button class="btn btn-light text-primary fw-bold" data-bs-toggle="modal" data-bs-target="#yeniFirmaModal">
                <i class="bi bi-plus-lg"></i> Yeni Firma Ekle
            </button>
        </div>

        <div class="custom-card">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Firma Adı</th>
                            <th>Yetkili</th>
                            <th>Plan</th>
                            <th class="text-center">Durum</th>
                            <th class="text-center">Kullanıcı</th>
                            <th class="text-center">Sözleşme</th>
                            <th>Kayıt Tarihi</th>
                            <th class="text-end">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($firmalar as $firma): ?>
                            <tr>
                                <td><?php echo $firma['id']; ?></td>
                                <td>
                                    <div class="fw-bold"><?php echo htmlspecialchars($firma['firma_adi']); ?></div>
                                    <small
                                        class="text-muted"><?php echo htmlspecialchars($firma['domain'] ?? '-'); ?></small>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($firma['yetkili_adi'] ?? '-'); ?><br>
                                    <small
                                        class="text-muted"><?php echo htmlspecialchars($firma['telefon'] ?? ''); ?></small>
                                </td>
                                <td><span class="badge bg-secondary"><?php echo strtoupper($firma['plan']); ?></span>
                                </td>
                                <td class="text-center">
                                    <?php if ($firma['durum']): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Pasif</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo $firma['kullanici_sayisi']; ?></td>
                                <td class="text-center"><?php echo $firma['sozlesme_sayisi']; ?></td>
                                <td><?php echo date('d.m.Y', strtotime($firma['olusturma_tarihi'])); ?></td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm">
                                        <a href="firma-duzenle.php?id=<?php echo $firma['id']; ?>"
                                            class="btn btn-outline-primary"><i class="bi bi-pencil"></i></a>
                                        <button class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Yeni Firma Modal -->
<div class="modal fade" id="yeniFirmaModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Yeni Firma Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form action="api/firma-ekle.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Firma Adı</label>
                        <input type="text" name="firma_adi" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Yetkili Adı</label>
                        <input type="text" name="yetkili_adi" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Telefon</label>
                        <input type="text" name="telefon" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Şifre</label>
                        <input type="password" name="sifre" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Plan</label>
                        <select name="plan" class="form-select">
                            <option value="free">Ücretsiz</option>
                            <option value="pro">Pro</option>
                            <option value="enterprise">Enterprise</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Kaydet</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>