<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Admin kontrolü - session'da admin_id olmalı
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$db = getDB();

// Genel sistem istatistikleri
$stats_sql = "SELECT 
                (SELECT COUNT(*) FROM firmalar WHERE durum = 1) as toplam_firma,
                (SELECT COUNT(*) FROM kullanicilar WHERE aktif = 1) as toplam_kullanici,
                (SELECT COUNT(*) FROM sozlesmeler) as toplam_sozlesme,
                (SELECT COUNT(*) FROM sozlesmeler WHERE durum = 'COMPLETED') as tamamlanan_sozlesme";

$stats_stmt = $db->query($stats_sql);
$stats = $stats_stmt->fetch();

// Son firmalar
$firmalar_sql = "SELECT f.*, 
                 (SELECT COUNT(*) FROM kullanicilar WHERE firma_id = f.id) as kullanici_sayisi,
                 (SELECT COUNT(*) FROM sozlesmeler WHERE firma_id = f.id) as sozlesme_sayisi
                 FROM firmalar f
                 WHERE f.durum = 1
                 ORDER BY f.olusturma_tarihi DESC
                 LIMIT 10";

$firmalar_stmt = $db->query($firmalar_sql);
$firmalar = $firmalar_stmt->fetchAll();

// Son aktiviteler
$aktivite_sql = "SELECT dk.*, k.isim, f.firma_adi
                FROM denetim_kayitlari dk
                LEFT JOIN kullanicilar k ON dk.kullanici_id = k.id
                LEFT JOIN firmalar f ON dk.firma_id = f.id
                ORDER BY dk.tarih DESC
                LIMIT 20";

$aktivite_stmt = $db->query($aktivite_sql);
$aktiviteler = $aktivite_stmt->fetchAll();

$page_title = 'Süper Admin Panel';
$body_class = 'admin-theme';
?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<!-- Main Content -->
<div class="main-content">
    <div class="container-fluid">
        <!-- Header Info -->
        <div class="d-flex justify-content-between align-items-center mb-4 text-white">
            <div>
                <h2 class="fw-bold mb-0">Dashboard</h2>
                <p class="mb-0 opacity-75">Sistem genel durum özeti</p>
            </div>
            <div class="d-none d-md-block">
                <span class="badge bg-white text-primary">
                    <i class="bi bi-calendar"></i> <?php echo date('d.m.Y'); ?>
                </span>
            </div>
        </div>

        <!-- İstatistikler -->
        <div class="row">
            <div class="col-md-6 col-lg-3">
                <div class="custom-card stat-card">
                    <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                        <i class="bi bi-building"></i>
                    </div>
                    <h3 class="mb-0"><?php echo $stats['toplam_firma']; ?></h3>
                    <p class="text-muted mb-0">Aktif Firma</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="custom-card stat-card">
                    <div class="stat-icon bg-success bg-opacity-10 text-success">
                        <i class="bi bi-people"></i>
                    </div>
                    <h3 class="mb-0"><?php echo $stats['toplam_kullanici']; ?></h3>
                    <p class="text-muted mb-0">Toplam Kullanıcı</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="custom-card stat-card">
                    <div class="stat-icon bg-info bg-opacity-10 text-info">
                        <i class="bi bi-file-text"></i>
                    </div>
                    <h3 class="mb-0"><?php echo $stats['toplam_sozlesme']; ?></h3>
                    <p class="text-muted mb-0">Toplam Sözleşme</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="custom-card stat-card">
                    <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                        <i class="bi bi-check-circle"></i>
                    </div>
                    <h3 class="mb-0"><?php echo $stats['tamamlanan_sozlesme']; ?></h3>
                    <p class="text-muted mb-0">Tamamlanan</p>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Firmalar -->
            <div class="col-lg-8">
                <div class="custom-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5><i class="bi bi-building"></i> Son Firmalar</h5>
                        <a href="firmalar.php" class="btn btn-sm btn-primary">
                            <i class="bi bi-plus"></i> Yeni Firma
                        </a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Firma Adı</th>
                                    <th>Domain</th>
                                    <th>Plan</th>
                                    <th class="text-center">Kullanıcı</th>
                                    <th class="text-center">Sözleşme</th>
                                    <th>Kayıt Tarihi</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($firmalar as $firma): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($firma['firma_adi']); ?></strong>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo htmlspecialchars($firma['domain'] ?? '-'); ?>
                                            </small>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php
                                            echo $firma['plan'] === 'enterprise' ? 'primary' :
                                                ($firma['plan'] === 'pro' ? 'success' : 'secondary');
                                            ?>">
                                                <?php echo strtoupper($firma['plan']); ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-info"><?php echo $firma['kullanici_sayisi']; ?></span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-success"><?php echo $firma['sozlesme_sayisi']; ?></span>
                                        </td>
                                        <td>
                                            <small><?php echo formatDate($firma['olusturma_tarihi'], 'd.m.Y'); ?></small>
                                        </td>
                                        <td>
                                            <a href="firma-detay.php?id=<?php echo $firma['id']; ?>"
                                                class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Aktiviteler -->
            <div class="col-lg-4">
                <div class="custom-card">
                    <h5 class="mb-3"><i class="bi bi-clock-history"></i> Son Aktiviteler</h5>
                    <div style="max-height: 500px; overflow-y: auto;">
                        <?php foreach ($aktiviteler as $aktivite): ?>
                            <div class="p-2 border-bottom">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <strong><?php echo htmlspecialchars($aktivite['isim'] ?? 'Sistem'); ?></strong>
                                        <br>
                                        <small
                                            class="text-muted"><?php echo htmlspecialchars($aktivite['islem']); ?></small>
                                        <?php if ($aktivite['firma_adi']): ?>
                                            <br>
                                            <small class="text-primary">
                                                <i class="bi bi-building"></i>
                                                <?php echo htmlspecialchars($aktivite['firma_adi']); ?>
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                    <small class="text-muted">
                                        <?php echo formatDate($aktivite['tarih'], 'H:i'); ?>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>