<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

$token = $_GET['token'] ?? '';
$db = getDB();

// Sözleşme bilgilerini al
$sozlesme_sql = "SELECT s.*, f.firma_adi, k.isim as danisman_adi, k.telefon as danisman_telefon
                 FROM sozlesmeler s
                 INNER JOIN whatsapp_linkleri wl ON s.id = wl.sozlesme_id
                 LEFT JOIN firmalar f ON s.firma_id = f.id
                 LEFT JOIN kullanicilar k ON s.danisman_id = k.id
                 WHERE wl.token = :token AND s.durum = 'COMPLETED'";

$sozlesme_stmt = $db->prepare($sozlesme_sql);
$sozlesme_stmt->execute([':token' => $token]);
$sozlesme = $sozlesme_stmt->fetch();

if (!$sozlesme) {
    die("Sözleşme bulunamadı!");
}

$musteri_bilgileri = json_decode($sozlesme['musteri_bilgileri'], true);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sözleşme Tamamlandı</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { 
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            min-height: 100vh;
            padding: 20px 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .success-container {
            background: white;
            border-radius: 20px;
            padding: 40px 25px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.3);
            max-width: 600px;
            text-align: center;
        }
        .success-animation {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
            animation: scaleIn 0.5s ease-out;
        }
        .success-animation i {
            color: white;
            font-size: 50px;
        }
        @keyframes scaleIn {
            0% { transform: scale(0); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        .info-card {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            margin: 20px 0;
            text-align: left;
        }
        .btn-download {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            border: none;
            border-radius: 10px;
            padding: 15px 30px;
            color: white;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            margin: 10px 5px;
        }
        .btn-whatsapp {
            background: #25D366;
            border: none;
            border-radius: 10px;
            padding: 15px 30px;
            color: white;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            margin: 10px 5px;
        }
        .confetti {
            position: fixed;
            width: 10px;
            height: 10px;
            background: #f0f;
            position: absolute;
            animation: fall 3s linear infinite;
        }
        @keyframes fall {
            to { transform: translateY(100vh) rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="success-container">
        <div class="success-animation">
            <i class="bi bi-file-earmark-check"></i>
        </div>
        
        <h2 class="text-success mb-3">
            Belge İmzalandı
        </h2>
        
        <p class="text-muted">
            Yer Gösterme Belgesi başarıyla çift imza ile onaylanmıştır.
        </p>

        <!-- Sözleşme Bilgileri -->
        <div class="info-card">
            <div class="row text-start">
                <div class="col-12 mb-2">
                    <small class="text-muted">Sözleşme No</small>
                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($sozlesme['islem_uuid']); ?></p>
                </div>
                <div class="col-12 mb-2">
                    <small class="text-muted">Firma</small>
                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($sozlesme['firma_adi']); ?></p>
                </div>
                <div class="col-12 mb-2">
                    <small class="text-muted">Danışman</small>
                    <p class="mb-0 fw-bold"><?php echo htmlspecialchars($sozlesme['danisman_adi']); ?></p>
                </div>
                <div class="col-12 mb-2">
                    <small class="text-muted">Tarih</small>
                    <p class="mb-0 fw-bold"><?php echo formatDate($sozlesme['guncelleme_tarihi'], 'd.m.Y H:i'); ?></p>
                </div>
            </div>
        </div>

        <!-- İşlemler -->
        <div class="mt-4">
            <?php if ($sozlesme['pdf_dosya_yolu']): ?>
                <a href="../<?php echo htmlspecialchars($sozlesme['pdf_dosya_yolu']); ?>" 
                   class="btn-download" target="_blank">
                    <i class="bi bi-download"></i> Belgeyi İndir (PDF)
                </a>
            <?php endif; ?>
            
            <?php if ($sozlesme['danisman_telefon']): ?>
                <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $sozlesme['danisman_telefon']); ?>" 
                   class="btn-whatsapp" target="_blank">
                    <i class="bi bi-whatsapp"></i> Danışmanla İletişim
                </a>
            <?php endif; ?>
        </div>
        
        <hr class="my-4">
        
        <p class="text-muted small mb-0">
            Bu belge elektronik olarak çift imza ile onaylanmış olup yasal geçerliliğe sahiptir.
            <br>Zaman damgası: <?php echo date('d.m.Y H:i:s'); ?>
        </p>
    </div>

    <script>
        // Konfeti animasyonu
        function createConfetti() {
            const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];
            for (let i = 0; i < 50; i++) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                confetti.style.left = Math.random() * 100 + 'vw';
                confetti.style.animationDelay = Math.random() * 3 + 's';
                confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
                document.body.appendChild(confetti);
                
                setTimeout(() => confetti.remove(), 3000);
            }
        }
        
        createConfetti();
    </script>
</body>
</html>