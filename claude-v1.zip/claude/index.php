<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Zaten giriş yapmışsa ilgili panele yönlendir
if (isLoggedIn()) {
    if (isAdmin()) {
        header("Location: admin/dashboard.php");
    } elseif (isFirmaSahibi()) {
        header("Location: firma/dashboard.php");
    } elseif (isDanisman()) {
        header("Location: danisman/dashboard.php");
    } else {
        header("Location: danisman/dashboard.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emlak İmza - Dijital Yer Gösterme Belgesi</title>
    <meta name="description" content="Emlak danışmanları için mobil öncelikli sözleşme imzalama platformu. WhatsApp ile gönder, anında imzalat.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Landing Page Custom Styles */
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --accent-gradient: linear-gradient(135deg, #FF6B6B 0%, #EE5253 100%);
            --surface-color: #ffffff;
            --text-primary: #2d3436;
            --text-secondary: #636e72;
        }

        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            color: var(--text-primary);
            overflow-x: hidden;
        }

        /* Hero Section */
        .hero-section {
            background: var(--primary-gradient);
            position: relative;
            overflow: hidden;
            color: white;
            padding-bottom: 80px;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at top right, rgba(255,255,255,0.1) 0%, transparent 60%);
            pointer-events: none;
        }

        .navbar-brand {
            color: white !important;
            font-weight: 700;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-box {
            width: 40px;
            height: 40px;
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .hero-title {
            font-size: 3.5rem;
            font-weight: 800;
            line-height: 1.2;
            margin-bottom: 25px;
        }

        .hero-subtitle {
            font-size: 1.25rem;
            opacity: 0.9;
            margin-bottom: 40px;
            font-weight: 300;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .text-accent {
            color: #ff9f43;
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fade-in {
            animation: fadeInUp 0.8s ease-out forwards;
        }

        /* Buttons */
        .btn-xl {
            padding: 15px 40px;
            font-size: 1.1rem;
            border-radius: 50px;
            font-weight: 600;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .btn-accent {
            background: white;
            color: #667eea;
            border: none;
        }

        .btn-accent:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            background: #f8f9fa;
            color: #764ba2;
        }

        .btn-outline-light-soft {
            border: 2px solid rgba(255,255,255,0.3);
            color: white;
            background: transparent;
        }

        .btn-outline-light-soft:hover {
            background: rgba(255,255,255,0.1);
            border-color: rgba(255,255,255,0.5);
            color: white;
        }

        /* Features */
        .feature-card {
            background: white;
            border-radius: 20px;
            padding: 40px 30px;
            height: 100%;
            transition: all 0.3s ease;
            border: 1px solid #f0f0f0;
        }

        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.08);
            border-color: transparent;
        }

        .feature-icon {
            width: 70px;
            height: 70px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            font-size: 32px;
        }

        /* CTA Section */
        .cta-section {
            background: var(--primary-gradient);
            color: white;
            padding: 80px 0;
            text-align: center;
        }

        /* Footer */
        .footer {
            background: #f8f9fa;
            padding: 40px 0;
            color: var(--text-secondary);
            border-top: 1px solid #eee;
        }
    </style>
</head>
<body>

    <!-- Hero Section -->
    <header class="hero-section">
        <nav class="navbar navbar-expand-lg navbar-dark pt-4">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <div class="logo-box">
                        <i class="bi bi-file-earmark-check-fill"></i>
                    </div>
                    imzala.com
                </a>
                <div class="ms-auto">
                    <a href="giris.php" class="btn btn-outline-light rounded-pill px-4 fw-bold">Giriş Yap</a>
                </div>
            </div>
        </nav>

        <div class="container pt-5 pb-5 text-center">
            <div class="row justify-content-center">
                <div class="col-lg-10 animate-fade-in">
                    <h1 class="hero-title">
                        Yer Gösterme Belgesi<br>
                        <span class="text-accent">Artık Dijital</span>
                    </h1>
                    <p class="hero-subtitle">
                        Emlak danışmanları için mobil öncelikli sözleşme imzalama platformu. 
                        Müşterilerinize WhatsApp üzerinden sözleşme gönderin, anında imza alın.
                    </p>
                    <div class="d-flex flex-column flex-md-row justify-content-center gap-3 mt-4">
                        <a href="giris.php" class="btn btn-accent btn-xl">
                            Hemen Başla <i class="bi bi-arrow-right ms-2"></i>
                        </a>
                        <a href="#features" class="btn btn-outline-light-soft btn-xl">
                            Nasıl Çalışır?
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Features Section -->
    <section id="features" class="py-5 my-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold display-6">Neden EmlakSign?</h2>
                <p class="text-muted lead">Emlak profesyonelleri için tasarlanmış modern çözümler</p>
            </div>

            <div class="row g-4">
                <!-- Feature 1 -->
                <div class="col-md-4">
                    <div class="feature-card text-center">
                        <div class="feature-icon" style="background: linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%); color: #667eea;">
                            <i class="bi bi-phone"></i>
                        </div>
                        <h3 class="h4 fw-bold mb-3">Mobil Öncelikli</h3>
                        <p class="text-muted">
                            %90 akıllı telefon kullanımı için optimize edildi. 
                            Müşteriler uygulama yüklemeden doğrudan imza atabilir.
                        </p>
                    </div>
                </div>

                <!-- Feature 2 -->
                <div class="col-md-4">
                    <div class="feature-card text-center">
                        <div class="feature-icon" style="background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 99%, #fecfef 100%); color: #ee5253;">
                            <i class="bi bi-stopwatch"></i>
                        </div>
                        <h3 class="h4 fw-bold mb-3">Zaman Kazanın</h3>
                        <p class="text-muted">
                            Yer gösterme öncesi sözleşme sürecini hızlandırın. 
                            WhatsApp ile anında müşteriye ulaşın.
                        </p>
                    </div>
                </div>

                <!-- Feature 3 -->
                <div class="col-md-4">
                    <div class="feature-card text-center">
                        <div class="feature-icon" style="background: linear-gradient(120deg, #d4fc79 0%, #96e6a1 100%); color: #20bf6b;">
                            <i class="bi bi-shield-check"></i>
                        </div>
                        <h3 class="h4 fw-bold mb-3">Güvenli & Yasal</h3>
                        <p class="text-muted">
                            Zaman damgası ve dijital imza ile yasal geçerliliğe sahip belgeler oluşturun.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h2 class="fw-bold mb-4">Firmalar İçin Özel Çözümler</h2>
                    <p class="lead mb-4 opacity-75">
                        Broker'lar sözleşme şablonlarını yüklesin, danışmanlar müşterilere göndersin. 
                        Tüm süreç tek platformda.
                    </p>
                    <a href="giris.php" class="btn btn-outline-light btn-xl">
                        Ücretsiz Deneyin <i class="bi bi-arrow-right ms-2"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container text-center">
            <div class="d-inline-flex align-items-center gap-2 mb-3">
                <div class="logo-box" style="background: #667eea; color: white; width: 32px; height: 32px;">
                    <i class="bi bi-file-earmark-check-fill small"></i>
                </div>
                <span class="fw-bold text-dark">imzala.com</span>
            </div>
            <p class="mb-0 small">© 2025 EmlakSign. Tüm hakları saklıdır.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>