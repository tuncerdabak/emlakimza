<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Admin kontrolü - session'da admin_id olmalı
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$db = getDB();

// Genel sistem istatistikleri
$stats_sql = "SELECT 
                (SELECT COUNT(*) FROM firmalar WHERE durum = 1) as toplam_firma,
                (SELECT COUNT(*) FROM kullanicilar WHERE aktif = 1) as toplam_kullanici,
                (SELECT COUNT(*) FROM sozlesmeler) as toplam_sozlesme,
                (SELECT COUNT(*) FROM sozlesmeler WHERE durum = 'COMPLETED') as tamamlanan_sozlesme";

$stats_stmt = $db->query($stats_sql);
$stats = $stats_stmt->fetch();

// Son firmalar
$firmalar_sql = "SELECT f.*, 
                 (SELECT COUNT(*) FROM kullanicilar WHERE firma_id = f.id) as kullanici_sayisi,
                 (SELECT COUNT(*) FROM sozlesmeler WHERE firma_id = f.id) as sozlesme_sayisi
                 FROM firmalar f
                 WHERE f.durum = 1
                 ORDER BY f.olusturma_tarihi DESC
                 LIMIT 10";

$firmalar_stmt = $db->query($firmalar_sql);
$firmalar = $firmalar_stmt->fetchAll();

// Son aktiviteler
$aktivite_sql = "SELECT dk.*, k.isim, f.firma_adi
                FROM denetim_kayitlari dk
                LEFT JOIN kullanicilar k ON dk.kullanici_id = k.id
                LEFT JOIN firmalar f ON dk.firma_id = f.id
                ORDER BY dk.tarih DESC
                LIMIT 20";

$aktivite_stmt = $db->query($aktivite_sql);
$aktiviteler = $aktivite_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Süper Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { 
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            min-height: 100vh;
        }
        .navbar-admin {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 15px 0;
        }
        .content-wrapper {
            padding: 30px 15px;
        }
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            width: 70px;
            height: 70px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            margin-bottom: 15px;
        }
        .table-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .activity-item {
            border-left: 3px solid #667eea;
            padding: 10px 15px;
            margin-bottom: 10px;
            background: #f8f9fa;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-admin sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="#">
                <i class="bi bi-shield-check"></i> Süper Admin Panel
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="firmalar.php">
                            <i class="bi bi-building"></i> Firmalar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kullanicilar.php">
                            <i class="bi bi-people"></i> Kullanıcılar
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sistem-ayarlari.php">
                            <i class="bi bi-gear"></i> Sistem Ayarları
                        </a>
                    </li>
                </ul>
                <div class="d-flex">
                    <span class="navbar-text me-3">
                        <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['admin_adsoyad']); ?>
                    </span>
                    <a href="./logout.php" class="btn btn-outline-danger btn-sm">
                        <i class="bi bi-box-arrow-right"></i> Çıkış
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="container-fluid content-wrapper">
        <!-- İstatistikler -->
        <div class="row">
            <div class="col-md-6 col-lg-3">
                <div class="stat-card">
                    <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                        <i class="bi bi-building"></i>
                    </div>
                    <h3 class="mb-0"><?php echo $stats['toplam_firma']; ?></h3>
                    <p class="text-muted mb-0">Aktif Firma</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="stat-card">
                    <div class="stat-icon bg-success bg-opacity-10 text-success">
                        <i class="bi bi-people"></i>
                    </div>
                    <h3 class="mb-0"><?php echo $stats['toplam_kullanici']; ?></h3>
                    <p class="text-muted mb-0">Toplam Kullanıcı</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="stat-card">
                    <div class="stat-icon bg-info bg-opacity-10 text-info">
                        <i class="bi bi-file-text"></i>
                    </div>
                    <h3 class="mb-0"><?php echo $stats['toplam_sozlesme']; ?></h3>
                    <p class="text-muted mb-0">Toplam Sözleşme</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="stat-card">
                    <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                        <i class="bi bi-check-circle"></i>
                    </div>
                    <h3 class="mb-0"><?php echo $stats['tamamlanan_sozlesme']; ?></h3>
                    <p class="text-muted mb-0">Tamamlanan</p>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Firmalar -->
            <div class="col-lg-8">
                <div class="table-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5><i class="bi bi-building"></i> Son Firmalar</h5>
                        <a href="firmalar.php" class="btn btn-sm btn-primary">
                            <i class="bi bi-plus"></i> Yeni Firma
                        </a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Firma Adı</th>
                                    <th>Domain</th>
                                    <th>Plan</th>
                                    <th class="text-center">Kullanıcı</th>
                                    <th class="text-center">Sözleşme</th>
                                    <th>Kayıt Tarihi</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($firmalar as $firma): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($firma['firma_adi']); ?></strong>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo htmlspecialchars($firma['domain'] ?? '-'); ?>
                                            </small>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $firma['plan'] === 'enterprise' ? 'primary' : 
                                                    ($firma['plan'] === 'pro' ? 'success' : 'secondary'); 
                                            ?>">
                                                <?php echo strtoupper($firma['plan']); ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-info"><?php echo $firma['kullanici_sayisi']; ?></span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-success"><?php echo $firma['sozlesme_sayisi']; ?></span>
                                        </td>
                                        <td>
                                            <small><?php echo formatDate($firma['olusturma_tarihi'], 'd.m.Y'); ?></small>
                                        </td>
                                        <td>
                                            <a href="firma-detay.php?id=<?php echo $firma['id']; ?>" 
                                               class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Aktiviteler -->
            <div class="col-lg-4">
                <div class="table-card">
                    <h5 class="mb-3"><i class="bi bi-clock-history"></i> Son Aktiviteler</h5>
                    <div style="max-height: 500px; overflow-y: auto;">
                        <?php foreach ($aktiviteler as $aktivite): ?>
                            <div class="activity-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <strong><?php echo htmlspecialchars($aktivite['isim'] ?? 'Sistem'); ?></strong>
                                        <br>
                                        <small class="text-muted"><?php echo htmlspecialchars($aktivite['islem']); ?></small>
                                        <?php if ($aktivite['firma_adi']): ?>
                                            <br>
                                            <small class="text-primary">
                                                <i class="bi bi-building"></i> 
                                                <?php echo htmlspecialchars($aktivite['firma_adi']); ?>
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                    <small class="text-muted">
                                        <?php echo formatDate($aktivite['tarih'], 'H:i'); ?>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>