<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Admin kontrolü
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$db = getDB();

// Firmaları getir
$sql = "SELECT f.*, 
        (SELECT COUNT(*) FROM kullanicilar WHERE firma_id = f.id) as kullanici_sayisi,
        (SELECT COUNT(*) FROM sozlesmeler WHERE firma_id = f.id) as sozlesme_sayisi
        FROM firmalar f
        ORDER BY f.olusturma_tarihi DESC";
$stmt = $db->query($sql);
$firmalar = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Firmalar - Süper Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .navbar-admin {
            background: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .card {
            border: none;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-admin sticky-top mb-4">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="dashboard.php">
                <i class="bi bi-shield-check"></i> Süper Admin
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2"></i>
                            Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link active" href="firmalar.php"><i class="bi bi-building"></i>
                            Firmalar</a></li>
                    <li class="nav-item"><a class="nav-link" href="kullanicilar.php"><i class="bi bi-people"></i>
                            Kullanıcılar</a></li>
                    <li class="nav-item"><a class="nav-link" href="sistem-ayarlari.php"><i class="bi bi-gear"></i>
                            Ayarlar</a></li>
                </ul>
                <div class="d-flex align-items-center">
                    <span class="me-3"><i class="bi bi-person-circle"></i>
                        <?php echo htmlspecialchars($_SESSION['admin_adsoyad'] ?? 'Admin'); ?></span>
                    <a href="../logout.php" class="btn btn-outline-danger btn-sm"><i class="bi bi-box-arrow-right"></i>
                        Çıkış</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Firmalar</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#yeniFirmaModal">
                <i class="bi bi-plus-lg"></i> Yeni Firma Ekle
            </button>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Firma Adı</th>
                                <th>Yetkili</th>
                                <th>Plan</th>
                                <th class="text-center">Durum</th>
                                <th class="text-center">Kullanıcı</th>
                                <th class="text-center">Sözleşme</th>
                                <th>Kayıt Tarihi</th>
                                <th class="text-end">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($firmalar as $firma): ?>
                                <tr>
                                    <td><?php echo $firma['id']; ?></td>
                                    <td>
                                        <div class="fw-bold"><?php echo htmlspecialchars($firma['firma_adi']); ?></div>
                                        <small
                                            class="text-muted"><?php echo htmlspecialchars($firma['domain'] ?? '-'); ?></small>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($firma['yetkili_adi'] ?? '-'); ?><br>
                                        <small
                                            class="text-muted"><?php echo htmlspecialchars($firma['telefon'] ?? ''); ?></small>
                                    </td>
                                    <td><span class="badge bg-secondary"><?php echo strtoupper($firma['plan']); ?></span>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($firma['durum']): ?>
                                            <span class="badge bg-success">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Pasif</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center"><?php echo $firma['kullanici_sayisi']; ?></td>
                                    <td class="text-center"><?php echo $firma['sozlesme_sayisi']; ?></td>
                                    <td><?php echo date('d.m.Y', strtotime($firma['olusturma_tarihi'])); ?></td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm">
                                            <a href="firma-duzenle.php?id=<?php echo $firma['id']; ?>"
                                                class="btn btn-outline-primary"><i class="bi bi-pencil"></i></a>
                                            <button class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Yeni Firma Modal -->
    <div class="modal fade" id="yeniFirmaModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Yeni Firma Ekle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form action="api/firma-ekle.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Firma Adı</label>
                            <input type="text" name="firma_adi" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Yetkili Adı</label>
                            <input type="text" name="yetkili_adi" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Telefon</label>
                            <input type="text" name="telefon" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Şifre</label>
                            <input type="password" name="sifre" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Plan</label>
                            <select name="plan" class="form-select">
                                <option value="free">Ücretsiz</option>
                                <option value="pro">Pro</option>
                                <option value="enterprise">Enterprise</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Kaydet</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>