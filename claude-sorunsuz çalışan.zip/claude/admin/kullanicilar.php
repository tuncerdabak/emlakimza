<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Admin kontrolü
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

$db = getDB();

// Filtreler
$firma_id = $_GET['firma_id'] ?? null;
$rol = $_GET['rol'] ?? null;

// Sorgu
$sql = "SELECT k.*, f.firma_adi 
        FROM kullanicilar k 
        LEFT JOIN firmalar f ON k.firma_id = f.id 
        WHERE 1=1";
$params = [];

if ($firma_id) {
    $sql .= " AND k.firma_id = :firma_id";
    $params[':firma_id'] = $firma_id;
}

if ($rol) {
    $sql .= " AND k.rol = :rol";
    $params[':rol'] = $rol;
}

$sql .= " ORDER BY k.olusturma_tarihi DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$kullanicilar = $stmt->fetchAll();

// Firmalar listesi (Filtre için)
$firmalar = $db->query("SELECT id, firma_adi FROM firmalar ORDER BY firma_adi")->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcılar - Süper Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .navbar-admin {
            background: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .card {
            border: none;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-admin sticky-top mb-4">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="dashboard.php">
                <i class="bi bi-shield-check"></i> Süper Admin
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2"></i>
                            Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="firmalar.php"><i class="bi bi-building"></i>
                            Firmalar</a></li>
                    <li class="nav-item"><a class="nav-link active" href="kullanicilar.php"><i class="bi bi-people"></i>
                            Kullanıcılar</a></li>
                    <li class="nav-item"><a class="nav-link" href="sistem-ayarlari.php"><i class="bi bi-gear"></i>
                            Ayarlar</a></li>
                </ul>
                <div class="d-flex align-items-center">
                    <span class="me-3"><i class="bi bi-person-circle"></i>
                        <?php echo htmlspecialchars($_SESSION['admin_adsoyad'] ?? 'Admin'); ?></span>
                    <a href="../logout.php" class="btn btn-outline-danger btn-sm"><i class="bi bi-box-arrow-right"></i>
                        Çıkış</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Kullanıcılar</h2>
            <div class="d-flex gap-2">
                <form class="d-flex gap-2" method="GET">
                    <select name="firma_id" class="form-select" onchange="this.form.submit()">
                        <option value="">Tüm Firmalar</option>
                        <?php foreach ($firmalar as $f): ?>
                            <option value="<?php echo $f['id']; ?>" <?php echo $firma_id == $f['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($f['firma_adi']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="rol" class="form-select" onchange="this.form.submit()">
                        <option value="">Tüm Roller</option>
                        <option value="firma_sahibi" <?php echo $rol == 'firma_sahibi' ? 'selected' : ''; ?>>Firma Sahibi
                        </option>
                        <option value="danisman" <?php echo $rol == 'danisman' ? 'selected' : ''; ?>>Danışman</option>
                    </select>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>İsim</th>
                                <th>Firma</th>
                                <th>Rol</th>
                                <th>Email/Telefon</th>
                                <th class="text-center">Durum</th>
                                <th>Kayıt Tarihi</th>
                                <th class="text-end">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($kullanicilar as $user): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td>
                                        <div class="fw-bold"><?php echo htmlspecialchars($user['isim']); ?></div>
                                    </td>
                                    <td>
                                        <?php if ($user['firma_adi']): ?>
                                            <i class="bi bi-building"></i> <?php echo htmlspecialchars($user['firma_adi']); ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($user['rol'] == 'firma_sahibi'): ?>
                                            <span class="badge bg-primary">Firma Sahibi</span>
                                        <?php elseif ($user['rol'] == 'danisman'): ?>
                                            <span class="badge bg-info">Danışman</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary"><?php echo $user['rol']; ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div><?php echo htmlspecialchars($user['email']); ?></div>
                                        <small class="text-muted"><?php echo htmlspecialchars($user['telefon']); ?></small>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($user['aktif']): ?>
                                            <span class="badge bg-success">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Pasif</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('d.m.Y', strtotime($user['olusturma_tarihi'])); ?></td>
                                    <td class="text-end">
                                        <button class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></button>
                                        <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>