<?php

class ContractGenerator
{
    private $fontPath;
    private $outputDir;
    private $sablonPath;
    private $fields = [];

    public function __construct(string $sablonPath = null, string $fieldsJson = null)
    {
        // Şablon yolu verildiyse onu kullan, yoksa varsayılan (eski uyumluluk için)
        if ($sablonPath) {
            $this->sablonPath = __DIR__ . '/../' . $sablonPath; // dosya_yolu relative geliyor
        } else {
            $this->sablonPath = __DIR__ . '/../sozlesme.png';
        }

        // Alanları yükle
        if ($fieldsJson) {
            $this->fields = json_decode($fieldsJson, true) ?? [];
        }

        $this->fontPath = __DIR__ . '/../assets/fonts/arial.ttf';
        $this->outputDir = __DIR__ . '/../assets/uploads/sozlesmeler/';

        if (!file_exists($this->outputDir)) {
            mkdir($this->outputDir, 0755, true);
        }
    }

    /**
     * Önizleme için resmi oluşturur
     */
    public function generatePreview($data)
    {
        $image = $this->createImage();
        if (!$image)
            return false;

        $black = imagecolorallocate($image, 0, 0, 0);

        // Tarih (Özel durum, listede yoksa bile ekleyebiliriz veya editörde 'tarih' tipi seçilmeli)
        // Editör yapısında 'type' belirledik. Ona göre switch case yapacağız.

        // Veri Setini Hazırla
        $map = $this->prepareDataMap($data);

        // Dinamik Alanları Yaz
        foreach ($this->fields as $field) {
            $type = $field['type'];
            // İmzaları önizlemede gösterme
            if (strpos($type, 'imza') !== false)
                continue;

            $text = $map[$type] ?? '';
            $coords = [$field['x'], $field['y']];

            // Eğer font büyüklüğü veya kutu genişliği verisi gelirse burada işlenebilir
            // Şimdilik standart font
            $this->writeText($image, $text, $coords, $black);
        }

        return $image;
    }

    /**
     * Final imzalı resmi oluşturur
     */
    public function generateFinal($sozlesmeData, $musteriData, $imzalar)
    {
        $image = $this->createImage();
        if (!$image)
            return false;

        $black = imagecolorallocate($image, 0, 0, 0);
        $blue = imagecolorallocate($image, 0, 0, 150);

        // Tüm verileri birleştir
        $fullData = array_merge($sozlesmeData, $musteriData);
        $map = $this->prepareDataMap($fullData);

        // Alanları İşle
        foreach ($this->fields as $field) {
            $type = $field['type'];
            $coords = [$field['x'], $field['y']];

            if ($type === 'imza_yer_gosterme' && !empty($imzalar['ana'])) {
                $this->addSignature($image, $imzalar['ana'], $coords, $field['w'] ?? 200, $field['h'] ?? 100);
            } elseif ($type === 'imza_teyit' && !empty($imzalar['teyit'])) {
                $this->addSignature($image, $imzalar['teyit'], $coords, $field['w'] ?? 200, $field['h'] ?? 100);
            } elseif ($type === 'firma_logo') {
                $logoPath = $map['firma_logo'] ?? '';
                if ($logoPath) {
                    $this->addLogo($image, $logoPath, $coords, $field['w'] ?? 100, $field['h'] ?? 100);
                }
            } else {
                // Normal Metin
                $color = (strpos($type, 'musteri') !== false) ? $blue : $black;
                $text = $map[$type] ?? '';
                $this->writeText($image, $text, $coords, $color);
            }
        }

        return $image;
    }

    private function prepareDataMap($data)
    {
        // Gayrimenkul JSON verisini çöz
        $emlak = [];
        if (!empty($data['gayrimenkul_detaylari'])) {
            $emlak = json_decode($data['gayrimenkul_detaylari'], true) ?? [];
        }

        // Firma Bilgileri (Data içinde gelmeli veya burada DB'den çekilmeli. 
        // Performans için data içinde gelmesini bekliyoruz, controller tarafından gönderilmeli.)

        return [
            // Genel
            'tarih' => date('d.m.Y'),

            // Firma
            'ticari_unvan' => $data['firma_adi'] ?? '',
            'firma_adres' => $data['firma_adres'] ?? '',
            'firma_telefon' => $data['firma_telefon'] ?? '',
            'yetki_belge_no' => $data['yetki_belge_no'] ?? '',
            'firma_logo' => $data['logo_yolu'] ?? '', // Logo yolu (veritabanından)


            // Danışman
            'danisman_ad' => $data['danisman_adi'] ?? '',
            'danisman_telefon' => $data['danisman_telefon'] ?? ($data['firma_telefon'] ?? ''),

            // Gayrimenkul (Detaylı)
            'il' => $emlak['il'] ?? '',
            'ilce' => $emlak['ilce'] ?? '',
            'mahalle' => $emlak['mahalle'] ?? '',
            'ada' => $emlak['ada'] ?? '',
            'parsel' => $emlak['parsel'] ?? '',
            'bagimsiz_bolum' => $emlak['bagimsiz_bolum'] ?? '',
            'nitelik' => $emlak['nitelik'] ?? '',
            'tam_adres' => $emlak['adres'] ?? ($data['gayrimenkul_adres'] ?? ''),
            'fiyat' => isset($data['fiyat']) ? number_format($data['fiyat'], 0, '', '.') . ' TL' : '',
            'hizmet_bedeli' => $emlak['hizmet_bedeli'] ?? '',

            // Müşteri
            'musteri_ad' => $data['ad_soyad'] ?? '',
            'musteri_tc' => $data['tc_kimlik'] ?? '',
            'musteri_telefon' => $data['telefon'] ?? '',
            'musteri_email' => $data['email'] ?? '',
            'musteri_adres' => $data['adres'] ?? '', // Müşteri adres verisi (nereden gelecek?)
        ];
    }

    public function saveImage($image, $filename)
    {
        $path = $this->outputDir . $filename;
        imagepng($image, $path);
        imagedestroy($image);
        return '/assets/uploads/sozlesmeler/' . $filename;
    }

    public function outputImage($image)
    {
        header('Content-Type: image/png');
        imagepng($image);
        imagedestroy($image);
    }

    private function createImage()
    {
        if (!file_exists($this->sablonPath)) {
            error_log("Şablon dosya bulunamadı: " . $this->sablonPath);
            // Fallback: Beyaz sayfa
            $im = imagecreatetruecolor(800, 1200);
            $white = imagecolorallocate($im, 255, 255, 255);
            imagefill($im, 0, 0, $white);
            return $im;
        }

        // Uzantıya göre yükle
        $ext = strtolower(pathinfo($this->sablonPath, PATHINFO_EXTENSION));
        if ($ext === 'jpg' || $ext === 'jpeg') {
            return imagecreatefromjpeg($this->sablonPath);
        } elseif ($ext === 'png') {
            return imagecreatefrompng($this->sablonPath);
        }

        return imagecreatefromstring(file_get_contents($this->sablonPath));
    }

    private function writeText($image, $text, $coords, $color, $fontSize = 12)
    {
        if (empty($text))
            return;

        if (file_exists($this->fontPath)) {
            imagettftext($image, $fontSize, 0, $coords[0], $coords[1] + $fontSize, $color, $this->fontPath, $text);
        } else {
            imagestring($image, 5, $coords[0], $coords[1], $text, $color);
        }
    }

    private function addSignature($image, $base64Sign, $coords, $width, $height)
    {
        if (empty($base64Sign))
            return;

        $base64Sign = str_replace('data:image/png;base64,', '', $base64Sign);
        $base64Sign = str_replace(' ', '+', $base64Sign);
        $signData = base64_decode($base64Sign);
        if (!$signData)
            return;

        $signImage = imagecreatefromstring($signData);
        if (!$signImage)
            return;

        imagealphablending($signImage, true);
        imagesavealpha($signImage, true);

        // Orantılı boyutlandır
        $origWidth = imagesx($signImage);
        $origHeight = imagesy($signImage);

        // Hedef boyutlar (Editörden gelen w/h)
        $newWidth = $width;
        $newHeight = $height;

        $resizedSign = imagecreatetruecolor($newWidth, $newHeight);

        imagealphablending($resizedSign, false);
        imagesavealpha($resizedSign, true);
        $transparent = imagecolorallocatealpha($resizedSign, 255, 255, 255, 127);
        imagefilledrectangle($resizedSign, 0, 0, $newWidth, $newHeight, $transparent);

        imagecopyresampled($resizedSign, $signImage, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);

        imagecopy($image, $resizedSign, $coords[0], $coords[1], 0, 0, $newWidth, $newHeight);

        imagedestroy($signImage);
        imagedestroy($resizedSign);
    }
    private function addLogo($image, $logoPath, $coords, $width, $height)
    {
        // Logo yolu relative mi absolute mu? Veritabanında genellikle 'assets/uploads/logos/...' şeklinde kayıtlı
        $fullLogoPath = __DIR__ . '/../' . $logoPath;

        if (!file_exists($fullLogoPath)) {
            // Belki başında / vardır
            $fullLogoPath = __DIR__ . '/..' . $logoPath;
            if (!file_exists($fullLogoPath))
                return;
        }

        $logoExt = strtolower(pathinfo($fullLogoPath, PATHINFO_EXTENSION));
        if ($logoExt === 'png') {
            $logoImage = imagecreatefrompng($fullLogoPath);
        } elseif ($logoExt === 'jpg' || $logoExt === 'jpeg') {
            $logoImage = imagecreatefromjpeg($fullLogoPath);
        } else {
            return;
        }

        if (!$logoImage)
            return;

        // Orijinal boyutlar
        $origWidth = imagesx($logoImage);
        $origHeight = imagesy($logoImage);

        // Oran koru
        $ratio = $origWidth / $origHeight;

        // Hedef kutuya sığdır
        if ($width / $height > $ratio) {
            $newHeight = $height;
            $newWidth = $height * $ratio;
        } else {
            $newWidth = $width;
            $newHeight = $width / $ratio;
        }

        imagealphablending($logoImage, true);
        imagesavealpha($logoImage, true);

        // Resize için
        $resizedLogo = imagecreatetruecolor($newWidth, $newHeight);

        imagealphablending($resizedLogo, false);
        imagesavealpha($resizedLogo, true);

        // PNG Logo ise şeffaflık önemli
        $transparent = imagecolorallocatealpha($resizedLogo, 255, 255, 255, 127);
        imagefilledrectangle($resizedLogo, 0, 0, $newWidth, $newHeight, $transparent);

        imagecopyresampled($resizedLogo, $logoImage, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);

        // Ana resme ekle
        imagecopy($image, $resizedLogo, $coords[0], $coords[1], 0, 0, $newWidth, $newHeight);

        imagedestroy($logoImage);
        imagedestroy($resizedLogo);
    }
}
?>