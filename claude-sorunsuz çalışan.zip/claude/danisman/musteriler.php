<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

requireLogin('../danisman/login.php');

if (!isDanisman()) {
    header("Location: ../index.php");
    exit;
}

$db = getDB();
$danisman_id = $_SESSION['user_id'];

// Tüm sözleşmeleri getir
$sql = "SELECT musteri_bilgileri, olusturma_tarihi FROM sozlesmeler 
        WHERE danisman_id = :danisman_id 
        ORDER BY olusturma_tarihi DESC";
$stmt = $db->prepare($sql);
$stmt->execute([':danisman_id' => $danisman_id]);
$sozlesmeler = $stmt->fetchAll();

// Müşterileri ayıkla (Telefon numarasına göre benzersiz)
$musteriler = [];
foreach ($sozlesmeler as $sozlesme) {
    $bilgi = json_decode($sozlesme['musteri_bilgileri'], true);
    if ($bilgi && isset($bilgi['telefon'])) {
        $tel = $bilgi['telefon'];
        if (!isset($musteriler[$tel])) {
            $musteriler[$tel] = [
                'ad_soyad' => $bilgi['ad_soyad'],
                'telefon' => $tel,
                'email' => $bilgi['email'] ?? '-',
                'ilk_islem' => $sozlesme['olusturma_tarihi'],
                'son_islem' => $sozlesme['olusturma_tarihi'],
                'islem_sayisi' => 1
            ];
        } else {
            $musteriler[$tel]['islem_sayisi']++;
            // Tarih karşılaştırma (String olarak Y-m-d H:i:s formatında sıralı gelir ama yine de kontrol edelim)
            if ($sozlesme['olusturma_tarihi'] > $musteriler[$tel]['son_islem']) {
                $musteriler[$tel]['son_islem'] = $sozlesme['olusturma_tarihi'];
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Müşterilerim - Danışman Paneli</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4 text-white">
            <h3><i class="bi bi-people"></i> Müşterilerim</h3>
            <a href="dashboard.php" class="btn btn-light"><i class="bi bi-arrow-left"></i> Geri</a>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Ad Soyad</th>
                                <th>Telefon</th>
                                <th>Email</th>
                                <th class="text-center">İşlem Sayısı</th>
                                <th>Son İşlem</th>
                                <th class="text-end">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($musteriler)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">Henüz kayıtlı müşteri bulunmuyor.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($musteriler as $m): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?php echo htmlspecialchars($m['ad_soyad']); ?></div>
                                        </td>
                                        <td>
                                            <a href="tel:<?php echo $m['telefon']; ?>" class="text-decoration-none">
                                                <?php echo htmlspecialchars($m['telefon']); ?>
                                            </a>
                                        </td>
                                        <td><?php echo htmlspecialchars($m['email']); ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-primary rounded-pill"><?php echo $m['islem_sayisi']; ?></span>
                                        </td>
                                        <td><?php echo formatDate($m['son_islem']); ?></td>
                                        <td class="text-end">
                                            <a href="https://wa.me/90<?php echo substr(preg_replace('/[^0-9]/', '', $m['telefon']), -10); ?>"
                                                target="_blank" class="btn btn-sm btn-success" title="WhatsApp">
                                                <i class="bi bi-whatsapp"></i>
                                            </a>
                                            <!-- Detay butonu gelecekte eklenebilir -->
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>

</html>