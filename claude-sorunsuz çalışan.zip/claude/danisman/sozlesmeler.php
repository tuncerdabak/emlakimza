<?php

require_once '../config/database.php';

require_once '../includes/auth.php';

require_once '../includes/functions.php';



if (!isLoggedIn()) {

    header("Location: login.php");

    exit;

}



if (!isDanisman()) {

    header("Location: ../index.php");

    exit;

}



$db = getDB();

$danisman_id = $_SESSION['user_id'];



// Filtreleme

$durum_filtre = $_GET['durum'] ?? 'all';

$arama = $_GET['q'] ?? '';



// SQL oluştur

$sql = "SELECT s.*, 

        COUNT(si.id) as imza_sayisi,

        CASE 

            WHEN s.durum = 'COMPLETED' THEN 'success'
            WHEN s.durum = 'PENDING' THEN 'warning'
        END as badge_class

        FROM sozlesmeler s

        LEFT JOIN sozlesme_imzalar si ON s.id = si.sozlesme_id

        WHERE s.danisman_id = :danisman_id";



if ($durum_filtre !== 'all') {

    $sql .= " AND s.durum = :durum";

}



if (!empty($arama)) {

    $sql .= " AND (s.islem_uuid LIKE :arama OR s.gayrimenkul_adres LIKE :arama OR s.musteri_email LIKE :arama)";

}



$sql .= " GROUP BY s.id ORDER BY s.olusturma_tarihi DESC";



$stmt = $db->prepare($sql);

$stmt->bindValue(':danisman_id', $danisman_id, PDO::PARAM_INT);



if ($durum_filtre !== 'all') {

    $stmt->bindValue(':durum', $durum_filtre);

}



if (!empty($arama)) {

    $stmt->bindValue(':arama', "%$arama%");

}



$stmt->execute();

$sozlesmeler = $stmt->fetchAll();



// İstatistikler

$stats_sql = "SELECT 

    COUNT(*) as toplam,

    SUM(CASE WHEN durum = 'COMPLETED' THEN 1 ELSE 0 END) as tamamlanan

    FROM sozlesmeler WHERE danisman_id = :danisman_id";

$stats_stmt = $db->prepare($stats_sql);

$stats_stmt->execute([':danisman_id' => $danisman_id]);

$stats = $stats_stmt->fetch();

?>

<!DOCTYPE html>

<html lang="tr">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Sözleşmelerim - Emlak İmza</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">

    <style>
        body {

            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

            min-height: 100vh;

            padding-bottom: 80px;

        }

        .container {
            padding: 20px 15px;
        }

        .page-header {

            background: white;

            border-radius: 15px;

            padding: 20px;

            margin-bottom: 20px;

            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

        }

        .filter-card {

            background: white;

            border-radius: 15px;

            padding: 15px;

            margin-bottom: 20px;

            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

        }

        .contract-item {

            background: white;

            border-radius: 10px;

            padding: 15px;

            margin-bottom: 10px;

            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

            cursor: pointer;

            transition: transform 0.2s;

        }

        .contract-item:hover {

            transform: translateX(5px);

        }

        .bottom-nav {

            position: fixed;

            bottom: 0;

            left: 0;

            right: 0;

            background: white;

            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);

            padding: 10px 0;

            z-index: 1000;

        }

        .bottom-nav-item {

            text-align: center;

            color: #667eea;

            text-decoration: none;

            display: block;

            padding: 5px;

            font-size: 12px;

        }

        .bottom-nav-item i {

            font-size: 24px;

            display: block;

            margin-bottom: 5px;

        }

        .bottom-nav-item.active {

            color: #764ba2;

        }

        .stat-badge {

            display: inline-block;

            padding: 5px 15px;

            border-radius: 20px;

            font-size: 14px;

            font-weight: 600;

            margin: 5px;

        }
    </style>

</head>

<body>

    <div class="container">

        <div class="page-header">

            <div class="d-flex justify-content-between align-items-center">

                <div>

                    <h5 class="mb-0"><i class="bi bi-file-text"></i> Sözleşmelerim</h5>

                    <small class="text-muted">Tüm sözleşme geçmişi</small>

                </div>

                <a href="dashboard.php" class="btn btn-outline-primary btn-sm">

                    <i class="bi bi-arrow-left"></i> Geri

                </a>

            </div>



            <div class="mt-3">

                <span class="stat-badge bg-primary text-white">

                    <i class="bi bi-file-text"></i> <?php echo $stats['toplam']; ?> Toplam

                </span>

                <span class="stat-badge bg-success text-white">

                    <i class="bi bi-check-circle"></i> <?php echo $stats['tamamlanan']; ?> Tamamlanan

                </span>

                <span class="stat-badge bg-warning text-dark">

                    <i class="bi bi-clock"></i> <?php echo $stats['bekleyen']; ?> Bekleyen

                </span>

            </div>

        </div>



        <!-- Filtreler -->

        <div class="filter-card">

            <form method="GET" class="row g-2">
                <div class="col-12">
                    <input type="text" name="q" class="form-control" 
                           placeholder="Ara... (UUID, adres, e-posta)" 
                           value="<?php echo htmlspecialchars($arama); ?>">
                </div>
                <div class="col-6">
                    <select name="durum" class="form-select">
                        <option value="all" <?php echo $durum_filtre === 'all' ? 'selected' : ''; ?>>Tüm Durumlar</option>
                        <option value="PENDING" <?php echo $durum_filtre === 'PENDING' ? 'selected' : ''; ?>>İmza Bekliyor</option>
                        <option value="COMPLETED" <?php echo $durum_filtre === 'COMPLETED' ? 'selected' : ''; ?>>İmzalandı</option>
                    </select>
                </div>
                <div class="col-6">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-search"></i> Filtrele
                    </button>
                </div>
            </form>

    </div>



    <!-- Sözleşme Listesi -->

    <?php if (count($sozlesmeler) > 0): ?>

        <?php foreach ($sozlesmeler as $s): ?>

            <div class="contract-item" onclick="location.href='sozlesme-detay.php?id=<?php echo $s['id']; ?>'">

                <div class="d-flex justify-content-between align-items-start mb-2">

                    <div>

                        <strong><?php echo substr($s['islem_uuid'], 0, 18); ?>...</strong>

                        <?php echo getStatusBadge($s['durum']); ?>

                    </div>

                    <small class="text-muted">

                        <i class="bi bi-calendar"></i>

                        <?php echo formatDate($s['olusturma_tarihi'], 'd.m.Y'); ?>

                    </small>

                </div>



                <?php if ($s['gayrimenkul_adres']): ?>

                    <div class="mb-2">

                        <small class="text-muted">

                            <i class="bi bi-geo-alt"></i>

                            <?php echo htmlspecialchars(substr($s['gayrimenkul_adres'], 0, 50)); ?>...

                        </small>

                    </div>

                <?php endif; ?>



                <div class="d-flex justify-content-between align-items-center">

                    <small>

                        <i class="bi bi-pen"></i>

                        <?php echo $s['imza_sayisi']; ?> İmza

                    </small>



                    <?php if ($s['fiyat']): ?>

                        <strong class="text-success">

                            <?php echo formatMoney($s['fiyat']); ?>

                        </strong>

                    <?php endif; ?>

                </div>

            </div>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="filter-card text-center py-5">

            <i class="bi bi-inbox" style="font-size: 48px; color: #ccc;"></i>

            <p class="text-muted mt-3">

                <?php echo !empty($arama) ? 'Aramanızla eşleşen sözleşme bulunamadı' : 'Henüz sözleşme bulunmuyor'; ?>

            </p>

            <?php if (!empty($arama) || $durum_filtre !== 'all'): ?>

                <a href="sozlesmeler.php" class="btn btn-primary btn-sm">

                    <i class="bi bi-x-circle"></i> Filtreyi Temizle

                </a>

            <?php else: ?>

                <a href="sozlesme-gonder.php" class="btn btn-primary">

                    <i class="bi bi-plus-circle"></i> İlk Sözleşmeni Gönder

                </a>

            <?php endif; ?>

        </div>

    <?php endif; ?>

    </div>



    <!-- Bottom Navigation -->

    <div class="bottom-nav">

        <div class="row g-0">

            <div class="col">

                <a href="dashboard.php" class="bottom-nav-item">

                    <i class="bi bi-house-door"></i>

                    Ana Sayfa

                </a>

            </div>

            <div class="col">

                <a href="sozlesme-gonder.php" class="bottom-nav-item">

                    <i class="bi bi-send"></i>

                    Gönder

                </a>

            </div>

            <div class="col">

                <a href="sozlesmeler.php" class="bottom-nav-item active">

                    <i class="bi bi-file-text-fill"></i>

                    Sözleşmeler

                </a>

            </div>

            <div class="col">

                <a href="profil.php" class="bottom-nav-item">

                    <i class="bi bi-person"></i>

                    Profil

                </a>

            </div>

        </div>

    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>