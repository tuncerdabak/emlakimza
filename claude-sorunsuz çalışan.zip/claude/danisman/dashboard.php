<?php

require_once '../config/database.php';

require_once '../includes/auth.php';

require_once '../includes/functions.php';



// Giriş kontrolü

requireLogin('../danisman/login.php');



// Sadece danışmanlar erişebilir

if (!isDanisman()) {

    header("Location: ../index.php");

    exit;

}



$db = getDB();

$danisman_id = $_SESSION['user_id'];

$firma_id = $_SESSION['firma_id'];



// İstatistikler

$stats_sql = "SELECT 

                COUNT(*) as toplam_sozlesme,

                SUM(CASE WHEN durum = 'COMPLETED' THEN 1 ELSE 0 END) as tamamlanan,

                SUM(CASE WHEN durum = 'PENDING' THEN 1 ELSE 0 END) as bekleyen,

                SUM(CASE WHEN durum = 'CANCELLED' THEN 1 ELSE 0 END) as iptal

              FROM sozlesmeler 

              WHERE danisman_id = :danisman_id";



$stats_stmt = $db->prepare($stats_sql);

$stats_stmt->execute([':danisman_id' => $danisman_id]);
$stats = $stats_stmt->fetch();

// Son sözleşmeler (Durumlar: PENDING -> COMPLETED)
$sozlesme_sql = "SELECT s.*, 
                 CASE 
                    WHEN s.durum = 'COMPLETED' THEN 'Tamamlandı'
                    WHEN s.durum = 'PENDING' THEN 'Beklemede'
                    WHEN s.durum = 'CANCELLED' THEN 'İptal Edildi'
                    ELSE 'Bilinmiyor'
                 END as durum_text
                 FROM sozlesmeler s
                 WHERE s.danisman_id = :danisman_id
                 ORDER BY s.olusturma_tarihi DESC
                 LIMIT 10";

$sozlesme_stmt = $db->prepare($sozlesme_sql);
$sozlesme_stmt->execute([':danisman_id' => $danisman_id]);

$sozlesmeler = $sozlesme_stmt->fetchAll();



?>

<!DOCTYPE html>

<html lang="tr">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Danışman Panel - Emlak İmza Sistemi</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">

    <style>
        body {

            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);

            min-height: 100vh;

            padding-bottom: 80px;

        }

        .dashboard-container {

            padding: 20px 15px;

        }

        .stat-card {

            background: white;

            border-radius: 15px;

            padding: 20px;

            margin-bottom: 15px;

            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);

            transition: transform 0.3s;

        }

        .stat-card:hover {

            transform: translateY(-5px);

        }

        .stat-icon {

            width: 60px;

            height: 60px;

            border-radius: 12px;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 24px;

        }

        .btn-action {

            border-radius: 10px;

            padding: 12px;

            font-weight: 600;

            margin-bottom: 10px;

        }

        .contract-card {

            background: white;

            border-radius: 10px;

            padding: 15px;

            margin-bottom: 10px;

            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

        }

        .navbar-custom {

            background: white;

            border-radius: 15px;

            margin-bottom: 20px;

            padding: 15px;

            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

        }

        .bottom-nav {

            position: fixed;

            bottom: 0;

            left: 0;

            right: 0;

            background: white;

            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);

            padding: 10px 0;

            z-index: 1000;

        }

        .bottom-nav-item {

            text-align: center;

            color: #667eea;

            text-decoration: none;

            display: block;

            padding: 5px;

            font-size: 12px;

        }

        .bottom-nav-item i {

            font-size: 24px;

            display: block;

            margin-bottom: 5px;

        }

        .bottom-nav-item.active {

            color: #764ba2;

        }
    </style>

</head>

<body>

    <div class="dashboard-container">

        <!-- Header -->

        <div class="navbar-custom">

            <div class="d-flex justify-content-between align-items-center">

                <div>

                    <h5 class="mb-0">Hoş Geldiniz</h5>

                    <small class="text-muted"><?php echo htmlspecialchars($_SESSION['user_isim']); ?></small>

                </div>

                <a href="../logout.php" class="btn btn-outline-danger btn-sm">

                    <i class="bi bi-box-arrow-right"></i> Çıkış

                </a>

            </div>

        </div>



        <!-- İstatistik Kartları -->

        <div class="row g-3 mb-3">

            <div class="col-6">

                <div class="stat-card">

                    <div class="d-flex align-items-center mb-2">

                        <div class="stat-icon bg-primary bg-opacity-10 text-primary me-3">

                            <i class="bi bi-file-text"></i>

                        </div>

                        <div>

                            <h6 class="mb-0 text-muted">Toplam</h6>

                            <h3 class="mb-0"><?php echo $stats['toplam_sozlesme']; ?></h3>

                        </div>

                    </div>

                </div>

            </div>

            <div class="col-6">

                <div class="stat-card">

                    <div class="d-flex align-items-center mb-2">

                        <div class="stat-icon bg-success bg-opacity-10 text-success me-3">

                            <i class="bi bi-check-circle"></i>

                        </div>

                        <div>

                            <h6 class="mb-0 text-muted">Tamamlanan</h6>

                            <h3 class="mb-0"><?php echo $stats['tamamlanan']; ?></h3>

                        </div>

                    </div>

                </div>

            </div>

            <div class="col-6">

                <div class="stat-card">

                    <div class="d-flex align-items-center mb-2">

                        <div class="stat-icon bg-warning bg-opacity-10 text-warning me-3">

                            <i class="bi bi-clock"></i>

                        </div>

                        <div>

                            <h6 class="mb-0 text-muted">Bekleyen</h6>

                            <h3 class="mb-0"><?php echo $stats['bekleyen']; ?></h3>

                        </div>

                    </div>

                </div>

            </div>

            <div class="col-6">

                <div class="stat-card">

                    <div class="d-flex align-items-center mb-2">

                        <div class="stat-icon bg-danger bg-opacity-10 text-danger me-3">

                            <i class="bi bi-x-circle"></i>

                        </div>

                        <div>

                            <h6 class="mb-0 text-muted">İptal</h6>

                            <h3 class="mb-0"><?php echo $stats['iptal']; ?></h3>

                        </div>

                    </div>

                </div>

            </div>

        </div>



        <!-- Hızlı İşlemler -->

        <div class="stat-card mb-3">

            <h6 class="mb-3">Hızlı İşlemler</h6>

            <a href="sozlesme-gonder.php" class="btn btn-primary btn-action w-100">

                <i class="bi bi-send"></i> Yeni Sözleşme Gönder

            </a>

            <a href="musteriler.php" class="btn btn-outline-primary btn-action w-100">

                <i class="bi bi-people"></i> Müşterilerim

            </a>

            <a href="portfoy.php" class="btn btn-outline-secondary btn-action w-100">

                <i class="bi bi-building"></i> Portföyüm

            </a>

        </div>



        <!-- Son Sözleşmeler -->

        <div class="stat-card">

            <h6 class="mb-3">Son Sözleşmeler</h6>

            <?php if (count($sozlesmeler) > 0): ?>

                <?php foreach ($sozlesmeler as $sozlesme): ?>

                    <div class="contract-card">

                        <div class="d-flex justify-content-between align-items-start mb-2">

                            <div>

                                <strong><?php echo htmlspecialchars($sozlesme['islem_uuid']); ?></strong>

                                <br>

                                <small class="text-muted">

                                    <?php echo htmlspecialchars($sozlesme['gayrimenkul_adres']); ?>

                                </small>

                            </div>

                            <?php echo getStatusBadge($sozlesme['durum']); ?>

                        </div>



                        <div class="d-flex justify-content-between align-items-center mb-2">

                            <small class="text-muted">

                                <i class="bi bi-calendar"></i>

                                <?php echo formatDate($sozlesme['olusturma_tarihi']); ?>

                            </small>

                            <?php if ($sozlesme['fiyat']): ?>

                                <small class="text-success fw-bold">

                                    <?php echo formatMoney($sozlesme['fiyat']); ?>

                                </small>

                            <?php endif; ?>

                        </div>



                        <!-- 🔵 TEKRAR GÖNDER BUTONU -->

                        <a href="sozlesme-gonder.php?id=<?php echo $sozlesme['id']; ?>"
                            class="btn btn-outline-primary w-100 mt-2">

                            <i class="bi bi-arrow-repeat"></i> Tekrar Gönder

                        </a>



                    </div>



                <?php endforeach; ?>

            <?php else: ?>

                <div class="alert alert-info">

                    Henüz sözleşme bulunmuyor. Yeni sözleşme göndermek için yukarıdaki butonu kullanın.

                </div>

            <?php endif; ?>

        </div>

    </div>



    <!-- Bottom Navigation -->

    <div class="bottom-nav">

        <div class="row g-0">

            <div class="col">

                <a href="dashboard.php" class="bottom-nav-item active">

                    <i class="bi bi-house-door-fill"></i>

                    Ana Sayfa

                </a>

            </div>

            <div class="col">

                <a href="sozlesme-gonder.php" class="bottom-nav-item">

                    <i class="bi bi-send"></i>

                    Gönder

                </a>

            </div>

            <div class="col">

                <a href="sozlesmeler.php" class="bottom-nav-item">

                    <i class="bi bi-file-text"></i>

                    Sözleşmeler

                </a>

            </div>

            <div class="col">

                <a href="profil.php" class="bottom-nav-item">

                    <i class="bi bi-person"></i>

                    Profil

                </a>

            </div>

        </div>

    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>