<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

requireLogin('../danisman/login.php');

if (!isDanisman()) {
    header("Location: ../index.php");
    exit;
}

$db = getDB();
$danisman_id = $_SESSION['user_id'];
$firma_id = $_SESSION['firma_id'];
$message = '';
$message_type = '';

// İşlemler
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['ekle'])) {
        $baslik = sanitizeInput($_POST['baslik']);
        
        $il = sanitizeInput($_POST['il'] ?? '');
        $ilce = sanitizeInput($_POST['ilce'] ?? '');
        $mahalle = sanitizeInput($_POST['mahalle'] ?? '');
        $ada = sanitizeInput($_POST['ada'] ?? '');
        $parsel = sanitizeInput($_POST['parsel'] ?? '');
        $bagimsiz_bolum = sanitizeInput($_POST['bagimsiz_bolum'] ?? '');
        $nitelik = sanitizeInput($_POST['nitelik'] ?? '');
        $adres = sanitizeInput($_POST['adres'] ?? ''); // Tam adres
        
        $fiyat = (float) str_replace('.', '', $_POST['fiyat']);
        $notlar = sanitizeInput($_POST['notlar']);

        $sql = "INSERT INTO portfoyler 
                (firma_id, danisman_id, baslik, il, ilce, mahalle, ada, parsel, bagimsiz_bolum, nitelik, adres, fiyat, notlar) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($sql);

        try {
            if ($stmt->execute([$firma_id, $danisman_id, $baslik, $il, $ilce, $mahalle, $ada, $parsel, $bagimsiz_bolum, $nitelik, $adres, $fiyat, $notlar])) {
                $message = 'Portföy eklendi.';
                $message_type = 'success';
            }
        } catch (PDOException $e) {
            $message = 'Hata: ' . $e->getMessage();
            $message_type = 'danger';
        }

    } elseif (isset($_POST['guncelle'])) {
        $id = (int) $_POST['id'];
        $baslik = sanitizeInput($_POST['baslik']);
        
        $il = sanitizeInput($_POST['il'] ?? '');
        $ilce = sanitizeInput($_POST['ilce'] ?? '');
        $mahalle = sanitizeInput($_POST['mahalle'] ?? '');
        $ada = sanitizeInput($_POST['ada'] ?? '');
        $parsel = sanitizeInput($_POST['parsel'] ?? '');
        $bagimsiz_bolum = sanitizeInput($_POST['bagimsiz_bolum'] ?? '');
        $nitelik = sanitizeInput($_POST['nitelik'] ?? '');
        $adres = sanitizeInput($_POST['adres'] ?? '');
        
        $fiyat = (float) str_replace('.', '', $_POST['fiyat']);
        $notlar = sanitizeInput($_POST['notlar']);
        $durum = $_POST['durum'];

        $sql = "UPDATE portfoyler SET 
                baslik=?, il=?, ilce=?, mahalle=?, ada=?, parsel=?, bagimsiz_bolum=?, nitelik=?, adres=?, fiyat=?, notlar=?, durum=? 
                WHERE id=? AND danisman_id=?";
        $stmt = $db->prepare($sql);

        if ($stmt->execute([$baslik, $il, $ilce, $mahalle, $ada, $parsel, $bagimsiz_bolum, $nitelik, $adres, $fiyat, $notlar, $durum, $id, $danisman_id])) {
            $message = 'Portföy güncellendi.';
            $message_type = 'success';
        }
    } elseif (isset($_POST['sil'])) {
        $id = (int) $_POST['id'];
        $stmt = $db->prepare("DELETE FROM portfoyler WHERE id=? AND danisman_id=?");
        if ($stmt->execute([$id, $danisman_id])) {
            $message = 'Portföy silindi.';
            $message_type = 'warning';
        }
    }
}

// Listeleme
$portfoyler = $db->prepare("SELECT * FROM portfoyler WHERE danisman_id = ? ORDER BY olusturma_tarihi DESC");
$portfoyler->execute([$danisman_id]);
$liste = $portfoyler->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portföy Yönetimi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .status-badge {
            position: absolute;
            top: 15px;
            right: 15px;
        }
        .location-info {
            font-size: 0.9rem;
            color: #6c757d;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4 text-white">
            <h3><i class="bi bi-briefcase"></i> Portföy Yönetimi</h3>
            <div>
                <a href="dashboard.php" class="btn btn-light me-2"><i class="bi bi-arrow-left"></i> Geri</a>
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#ekleModal">
                    <i class="bi bi-plus-lg"></i> Yeni Portföy
                </button>
            </div>
        </div>

        <?php if ($message): ?>
            <?php echo showAlert($message, $message_type); ?>
        <?php endif; ?>

        <div class="row">
            <?php foreach ($liste as $p): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <span class="badge bg-<?php echo $p['durum'] == 'yayinda' ? 'success' : 'secondary'; ?> status-badge">
                                <?php echo strtoupper($p['durum']); ?>
                            </span>
                            
                            <h5 class="card-title mt-2"><?php echo htmlspecialchars($p['baslik']); ?></h5>
                            <h6 class="text-primary fw-bold mb-3"><?php echo formatMoney($p['fiyat']); ?></h6>
                            
                            <div class="location-info mb-3">
                                <i class="bi bi-geo-alt-fill text-danger"></i> 
                                <?php echo htmlspecialchars($p['il'] . ' / ' . $p['ilce']); ?>
                                <br>
                                <small class="ms-3"><?php echo htmlspecialchars($p['mahalle']); ?></small>
                            </div>

                            <div class="small text-muted mb-3 border-top pt-2">
                                <span class="me-2"><i class="bi bi-house"></i> <?php echo htmlspecialchars($p['nitelik']); ?></span>
                                <span class="me-2"><i class="bi bi-grid-3x3"></i> <?php echo htmlspecialchars($p['ada'] . '/' . $p['parsel']); ?></span>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <a href="sozlesme-gonder.php?portfoy_id=<?php echo $p['id']; ?>" class="btn btn-outline-success">
                                    <i class="bi bi-file-earmark-text"></i> Sözleşme Hazırla
                                </a>
                                <div class="btn-group">
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $p['id']; ?>">
                                        <i class="bi bi-pencil"></i> Düzenle
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="confirmDelete(<?php echo $p['id']; ?>)">
                                        <i class="bi bi-trash"></i> Sil
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Düzenle Modal -->
                    <div class="modal fade" id="editModal<?php echo $p['id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Portföy Düzenle</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <form method="POST">
                                    <div class="modal-body">
                                        <input type="hidden" name="guncelle" value="1">
                                        <input type="hidden" name="id" value="<?php echo $p['id']; ?>">

                                        <div class="row g-3">
                                            <div class="col-12">
                                                <label class="form-label">Başlık</label>
                                                <input type="text" name="baslik" class="form-control" value="<?php echo htmlspecialchars($p['baslik']); ?>" required>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <label class="form-label">İl</label>
                                                <input type="text" name="il" class="form-control" value="<?php echo htmlspecialchars($p['il']); ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">İlçe</label>
                                                <input type="text" name="ilce" class="form-control" value="<?php echo htmlspecialchars($p['ilce']); ?>" required>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <label class="form-label">Mahalle</label>
                                                <input type="text" name="mahalle" class="form-control" value="<?php echo htmlspecialchars($p['mahalle']); ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Niteliği</label>
                                                <input type="text" name="nitelik" class="form-control" value="<?php echo htmlspecialchars($p['nitelik']); ?>" placeholder="Daire, Arsa...">
                                            </div>

                                            <div class="col-md-4">
                                                <label class="form-label">Ada</label>
                                                <input type="text" name="ada" class="form-control" value="<?php echo htmlspecialchars($p['ada']); ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label">Parsel</label>
                                                <input type="text" name="parsel" class="form-control" value="<?php echo htmlspecialchars($p['parsel']); ?>">
                                            </div>
                                            <div class="col-md-4">
                                                <label class="form-label">Bağ. Bölüm</label>
                                                <input type="text" name="bagimsiz_bolum" class="form-control" value="<?php echo htmlspecialchars($p['bagimsiz_bolum']); ?>">
                                            </div>

                                            <div class="col-12">
                                                <label class="form-label">Açık Adres</label>
                                                <textarea name="adres" class="form-control" rows="2" required><?php echo htmlspecialchars($p['adres']); ?></textarea>
                                            </div>

                                            <div class="col-md-6">
                                                <label class="form-label">Fiyat</label>
                                                <input type="text" name="fiyat" class="form-control price-input" value="<?php echo number_format($p['fiyat'], 0, '', '.'); ?>" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Durum</label>
                                                <select name="durum" class="form-select">
                                                    <option value="yayinda" <?php echo $p['durum'] == 'yayinda' ? 'selected' : ''; ?>>Yayında</option>
                                                    <option value="pasif" <?php echo $p['durum'] == 'pasif' ? 'selected' : ''; ?>>Pasif</option>
                                                    <option value="satildi" <?php echo $p['durum'] == 'satildi' ? 'selected' : ''; ?>>Satıldı</option>
                                                </select>
                                            </div>
                                            
                                            <div class="col-12">
                                                <label class="form-label">Notlar</label>
                                                <textarea name="notlar" class="form-control"><?php echo htmlspecialchars($p['notlar']); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Güncelle</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Ekle Modal -->
    <div class="modal fade" id="ekleModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Yeni Portföy Ekle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="ekle" value="1">

                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Başlık</label>
                                <input type="text" name="baslik" class="form-control" placeholder="Örn: 3+1 Lüks Daire" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">İl</label>
                                <input type="text" name="il" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">İlçe</label>
                                <input type="text" name="ilce" class="form-control" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Mahalle</label>
                                <input type="text" name="mahalle" class="form-control">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Niteliği</label>
                                <input type="text" name="nitelik" class="form-control" placeholder="Daire, Arsa...">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Ada</label>
                                <input type="text" name="ada" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Parsel</label>
                                <input type="text" name="parsel" class="form-control">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Bağ. Bölüm</label>
                                <input type="text" name="bagimsiz_bolum" class="form-control">
                            </div>

                            <div class="col-12">
                                <label class="form-label">Açık Adres</label>
                                <textarea name="adres" class="form-control" rows="2" placeholder="Tam adres..." required></textarea>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Fiyat</label>
                                <input type="text" name="fiyat" class="form-control price-input" placeholder="Örn: 2.500.000" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label class="form-label">Notlar</label>
                                <textarea name="notlar" class="form-control"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Gizli Silme Formu -->
    <form id="deleteForm" method="POST" style="display:none;">
        <input type="hidden" name="sil" value="1">
        <input type="hidden" name="id" id="deleteId">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Fiyat Formatlama
        document.querySelectorAll('.price-input').forEach(input => {
            input.addEventListener('keyup', function (e) {
                let value = this.value.replace(/[^\d]/g, '');
                if (value !== '') {
                    this.value = parseInt(value).toLocaleString('tr-TR');
                }
            });
        });

        function confirmDelete(id) {
            if (confirm('Bu portföyü silmek istediğinize emin misiniz?')) {
                document.getElementById('deleteId').value = id;
                document.getElementById('deleteForm').submit();
            }
        }
    </script>
</body>
</html>