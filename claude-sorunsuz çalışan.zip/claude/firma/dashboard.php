<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

requireLogin('../firma/login.php');
requireFirma();

$db = getDB();
$firma_id = $_SESSION['firma_id'];

// Firma istatistikleri
$stats_sql = "SELECT 
                COUNT(DISTINCT s.id) as toplam_sozlesme,
                COUNT(DISTINCT s.danisman_id) as aktif_danisman,
                SUM(CASE WHEN s.durum = 'COMPLETED' THEN 1 ELSE 0 END) as tamamlanan,
                SUM(CASE WHEN s.durum = 'PENDING' THEN 1 ELSE 0 END) as bekleyen,
                COUNT(DISTINCT DATE(s.olusturma_tarihi)) as aktif_gun
              FROM sozlesmeler s
              WHERE s.firma_id = :firma_id 
              AND s.olusturma_tarihi >= DATE_SUB(NOW(), INTERVAL 30 DAY)";

$stats_stmt = $db->prepare($stats_sql);
$stats_stmt->execute([':firma_id' => $firma_id]);
$stats = $stats_stmt->fetch();

// Danışman performansı
$danisman_sql = "SELECT k.id, k.isim, k.email,
                 COUNT(s.id) as toplam_sozlesme,
                 SUM(CASE WHEN s.durum = 'COMPLETED' THEN 1 ELSE 0 END) as basarili
                 FROM kullanicilar k
                 LEFT JOIN sozlesmeler s ON k.id = s.danisman_id
                 WHERE k.firma_id = :firma_id AND k.rol = 'danisman' AND k.aktif = 1
                 GROUP BY k.id
                 ORDER BY basarili DESC";

$danisman_stmt = $db->prepare($danisman_sql);
$danisman_stmt->execute([':firma_id' => $firma_id]);
$danismanlar = $danisman_stmt->fetchAll();

// Son sözleşmeler
$recent_sql = "SELECT s.*, k.isim as danisman_adi
               FROM sozlesmeler s
               LEFT JOIN kullanicilar k ON s.danisman_id = k.id
               WHERE s.firma_id = :firma_id
               ORDER BY s.olusturma_tarihi DESC
               LIMIT 10";

$recent_stmt = $db->prepare($recent_sql);
$recent_stmt->execute([':firma_id' => $firma_id]);
$recent_contracts = $recent_stmt->fetchAll();

// Şablon sayısı
$sablon_count_sql = "SELECT COUNT(*) as sayi FROM sozlesme_sablonlari WHERE firma_id = :firma_id AND aktif = 1";
$sablon_stmt = $db->prepare($sablon_count_sql);
$sablon_stmt->execute([':firma_id' => $firma_id]);
$sablon_count = $sablon_stmt->fetch()['sayi'];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Firma Yönetim Paneli</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .sidebar {
            background: white;
            min-height: 100vh;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        .sidebar .nav-link {
            color: #333;
            padding: 15px 20px;
            border-left: 3px solid transparent;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: #f8f9fa;
            border-left-color: #667eea;
            color: #667eea;
        }
        .content-area {
            padding: 30px;
        }
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            margin-bottom: 15px;
        }
        .table-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .header-bar {
            background: white;
            padding: 20px 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        @media (max-width: 768px) {
            .sidebar {
                min-height: auto;
                margin-bottom: 20px;
            }
            .content-area {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar d-none d-md-block">
                <div class="p-4">
                    <h5 class="text-center mb-4">
                        <i class="bi bi-building"></i> Firma Panel
                    </h5>
                    <nav class="nav flex-column">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                        <a class="nav-link" href="sablonlar.php">
                            <i class="bi bi-file-earmark-text"></i> Şablonlar
                            <span class="badge bg-primary"><?php echo $sablon_count; ?></span>
                        </a>
                        <a class="nav-link" href="danismanlar.php">
                            <i class="bi bi-people"></i> Danışmanlar
                        </a>
                        <a class="nav-link" href="raporlar.php">
                            <i class="bi bi-graph-up"></i> Raporlar
                        </a>
                        <a class="nav-link" href="ayarlar.php">
                            <i class="bi bi-gear"></i> Ayarlar
                        </a>
                        <hr>
                        <a class="nav-link text-danger" href="../logout.php">
                            <i class="bi bi-box-arrow-right"></i> Çıkış
                        </a>
                    </nav>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 content-area">
                <!-- Header -->
                <div class="header-bar d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-0">Hoş Geldiniz</h4>
                        <small class="text-muted"><?php echo htmlspecialchars($_SESSION['user_isim']); ?></small>
                    </div>
                    <div>
                        <span class="badge bg-primary">Son 30 Gün</span>
                    </div>
                </div>

                <!-- İstatistik Kartları -->
                <div class="row">
                    <div class="col-md-6 col-lg-3">
                        <div class="stat-card">
                            <div class="stat-icon bg-primary bg-opacity-10 text-primary">
                                <i class="bi bi-file-text"></i>
                            </div>
                            <h3 class="mb-0"><?php echo $stats['toplam_sozlesme']; ?></h3>
                            <p class="text-muted mb-0">Toplam Sözleşme</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="stat-card">
                            <div class="stat-icon bg-success bg-opacity-10 text-success">
                                <i class="bi bi-check-circle"></i>
                            </div>
                            <h3 class="mb-0"><?php echo $stats['tamamlanan']; ?></h3>
                            <p class="text-muted mb-0">Tamamlanan</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="stat-card">
                            <div class="stat-icon bg-warning bg-opacity-10 text-warning">
                                <i class="bi bi-clock"></i>
                            </div>
                            <h3 class="mb-0"><?php echo $stats['bekleyen']; ?></h3>
                            <p class="text-muted mb-0">Bekleyen</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="stat-card">
                            <div class="stat-icon bg-info bg-opacity-10 text-info">
                                <i class="bi bi-people"></i>
                            </div>
                            <h3 class="mb-0"><?php echo $stats['aktif_danisman']; ?></h3>
                            <p class="text-muted mb-0">Aktif Danışman</p>
                        </div>
                    </div>
                </div>

                <!-- Danışman Performansı -->
                <div class="table-card mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5><i class="bi bi-trophy"></i> Danışman Performansı</h5>
                        <a href="danismanlar.php" class="btn btn-sm btn-outline-primary">
                            Tümünü Gör
                        </a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Danışman</th>
                                    <th>E-posta</th>
                                    <th class="text-center">Toplam</th>
                                    <th class="text-center">Başarılı</th>
                                    <th class="text-center">Başarı Oranı</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($danismanlar as $danisman): ?>
                                    <?php 
                                    $oran = $danisman['toplam_sozlesme'] > 0 
                                        ? round(($danisman['basarili'] / $danisman['toplam_sozlesme']) * 100) 
                                        : 0;
                                    ?>
                                    <tr>
                                        <td>
                                            <i class="bi bi-person-circle"></i>
                                            <?php echo htmlspecialchars($danisman['isim']); ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($danisman['email']); ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-secondary"><?php echo $danisman['toplam_sozlesme']; ?></span>
                                        </td>
                                        <td class="text-center">
                                            <span class="badge bg-success"><?php echo $danisman['basarili']; ?></span>
                                        </td>
                                        <td class="text-center">
                                            <div class="progress" style="height: 20px;">
                                                <div class="progress-bar bg-success" role="progressbar" 
                                                     style="width: <?php echo $oran; ?>%">
                                                    <?php echo $oran; ?>%
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Son Sözleşmeler -->
                <div class="table-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5><i class="bi bi-clock-history"></i> Son Sözleşmeler</h5>
                        <a href="raporlar.php" class="btn btn-sm btn-outline-primary">
                            Tüm Raporlar
                        </a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>UUID</th>
                                    <th>Danışman</th>
                                    <th>Adres</th>
                                    <th>Durum</th>
                                    <th>Tarih</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_contracts as $contract): ?>
                                    <tr>
                                        <td>
                                            <small class="font-monospace">
                                                <?php echo substr($contract['islem_uuid'], 0, 13); ?>...
                                            </small>
                                        </td>
                                        <td><?php echo htmlspecialchars($contract['danisman_adi'] ?? 'Belirtilmemiş'); ?></td>
                                        <td>
                                            <small>
                                                <?php echo htmlspecialchars(substr($contract['gayrimenkul_adres'] ?? '', 0, 30)); ?>...
                                            </small>
                                        </td>
                                        <td><?php echo getStatusBadge($contract['durum']); ?></td>
                                        <td><small><?php echo formatDate($contract['olusturma_tarihi']); ?></small></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>