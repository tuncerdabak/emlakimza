<?php

require_once '../config/database.php';

require_once '../includes/auth.php';

require_once '../includes/functions.php';



if (!isLoggedIn() || !isFirmaSahibi()) {

    header("Location: login.php");

    exit;

}



$db = getDB();

$firma_id = $_SESSION['firma_id'];

$message = '';

$message_type = '';



// Dosya yükleme

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload'])) {

    $ad = sanitizeInput($_POST['ad'] ?? '');



    if (empty($ad)) {

        $message = 'Şablon adı gerekli!';

        $message_type = 'danger';

    } elseif (!isset($_FILES['dosya'])) {

        $message = 'Dosya seçilmedi!';

        $message_type = 'danger';

    } else {
        $allowed_extensions = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];
        $upload_result = uploadFile($_FILES['dosya'], $allowed_extensions);

        if ($upload_result['success']) {

            try {

                $sql = "INSERT INTO sozlesme_sablonlari (firma_id, ad, dosya_yolu, aktif) 

                        VALUES (:firma_id, :ad, :dosya_yolu, 1)";

                $stmt = $db->prepare($sql);

                $stmt->execute([

                    ':firma_id' => $firma_id,

                    ':ad' => $ad,

                    ':dosya_yolu' => $upload_result['filepath']

                ]);



                $message = 'Şablon başarıyla yüklendi!';

                $message_type = 'success';



                logActivity($_SESSION['user_id'], 'Şablon eklendi', ['sablon' => $ad], $firma_id);

            } catch (Exception $e) {

                $message = 'Kayıt hatası: ' . $e->getMessage();

                $message_type = 'danger';

            }

        } else {

            $message = $upload_result['message'];

            $message_type = 'danger';

        }

    }

}



// Durum değiştirme

if (isset($_GET['toggle']) && isset($_GET['id'])) {

    $id = (int) $_GET['id'];

    $toggle_sql = "UPDATE sozlesme_sablonlari SET aktif = NOT aktif WHERE id = :id AND firma_id = :firma_id";

    $toggle_stmt = $db->prepare($toggle_sql);

    $toggle_stmt->execute([':id' => $id, ':firma_id' => $firma_id]);

    header("Location: sablonlar.php");

    exit;

}



// Silme

if (isset($_GET['delete']) && isset($_GET['id'])) {

    $id = (int) $_GET['id'];



    // Önce dosyayı sil

    $file_sql = "SELECT dosya_yolu FROM sozlesme_sablonlari WHERE id = :id AND firma_id = :firma_id";

    $file_stmt = $db->prepare($file_sql);

    $file_stmt->execute([':id' => $id, ':firma_id' => $firma_id]);

    $file = $file_stmt->fetch();



    if ($file) {

        $filepath = __DIR__ . '/../' . $file['dosya_yolu'];

        if (file_exists($filepath)) {

            unlink($filepath);

        }



        $delete_sql = "DELETE FROM sozlesme_sablonlari WHERE id = :id AND firma_id = :firma_id";

        $delete_stmt = $db->prepare($delete_sql);

        $delete_stmt->execute([':id' => $id, ':firma_id' => $firma_id]);



        $message = 'Şablon silindi!';

        $message_type = 'success';

    }

}



// Şablonları getir

$sablonlar_sql = "SELECT * FROM sozlesme_sablonlari WHERE firma_id = :firma_id ORDER BY olusturma_tarihi DESC";

$sablonlar_stmt = $db->prepare($sablonlar_sql);

$sablonlar_stmt->execute([':firma_id' => $firma_id]);

$sablonlar = $sablonlar_stmt->fetchAll();

?>

<!DOCTYPE html>

<html lang="tr">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Şablon Yönetimi</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">

    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .sablon-item {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
    </style>

</head>

<body>

    <div class="container">

        <div class="card">

            <div class="card-body">

                <div class="d-flex justify-content-between align-items-center mb-3">

                    <h4><i class="bi bi-file-earmark-text"></i> Şablon Yönetimi</h4>

                    <a href="dashboard.php" class="btn btn-outline-primary">

                        <i class="bi bi-arrow-left"></i> Geri

                    </a>

                </div>



                <?php if ($message): ?>

                    <?php echo showAlert($message, $message_type); ?>

                <?php endif; ?>



                <!-- Yükleme Formu -->

                <form method="POST" enctype="multipart/form-data" class="mb-4">

                    <div class="row g-3">

                        <div class="col-md-4">

                            <input type="text" name="ad" class="form-control" placeholder="Şablon Adı" required>

                        </div>

                        <div class="col-md-5">

                            <input type="file" name="dosya" class="form-control"
                                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" required>

                        </div>

                        <div class="col-md-3">

                            <button type="submit" name="upload" class="btn btn-success w-100">

                                <i class="bi bi-upload"></i> Yükle

                            </button>

                        </div>

                    </div>

                    <small class="text-muted">Desteklenen formatlar: PNG, JPG, PDF, DOC, DOCX (Max 5MB)</small>

                </form>



                <!-- Şablon Listesi -->

                <h6>Mevcut Şablonlar (<?php echo count($sablonlar); ?>)</h6>

                <?php if (count($sablonlar) > 0): ?>

                    <?php foreach ($sablonlar as $s): ?>

                        <div class="sablon-item">

                            <div class="d-flex justify-content-between align-items-center">

                                <div>

                                    <strong><?php echo htmlspecialchars($s['ad']); ?></strong>

                                    <?php if ($s['aktif']): ?>

                                        <span class="badge bg-success">Aktif</span>

                                    <?php else: ?>

                                        <span class="badge bg-secondary">Pasif</span>

                                    <?php endif; ?>

                                    <br>

                                    <small class="text-muted">

                                        <i class="bi bi-calendar"></i> <?php echo formatDate($s['olusturma_tarihi']); ?>

                                    </small>

                                </div>

                                <div>

                                    <a href="sablon-duzenle.php?id=<?php echo $s['id']; ?>" class="btn btn-sm btn-primary"
                                        title="Düzenle">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a href="?toggle=1&id=<?php echo $s['id']; ?>" class="btn btn-sm btn-warning"
                                        title="Aktif/Pasif">

                                        <i class="bi bi-toggle-<?php echo $s['aktif'] ? 'on' : 'off'; ?>"></i>

                                    </a>

                                    <a href="../<?php echo $s['dosya_yolu']; ?>" class="btn btn-sm btn-info" target="_blank"
                                        title="İndir">

                                        <i class="bi bi-download"></i>

                                    </a>

                                    <a href="?delete=1&id=<?php echo $s['id']; ?>" class="btn btn-sm btn-danger"
                                        onclick="return confirm('Silmek istediğinize emin misiniz?')" title="Sil">

                                        <i class="bi bi-trash"></i>

                                    </a>

                                </div>

                            </div>

                        </div>

                    <?php endforeach; ?>

                <?php else: ?>

                    <div class="alert alert-info">

                        <i class="bi bi-info-circle"></i> Henüz şablon yüklenmemiş.

                    </div>

                <?php endif; ?>

            </div>

        </div>

    </div>

</body>

</html>