<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

if (!isLoggedIn() || !isFirmaSahibi()) {
    header("Location: login.php");
    exit;
}

$db = getDB();
$firma_id = $_SESSION['firma_id'];
$id = (int) ($_GET['id'] ?? 0);

// Şablonu getir
$stmt = $db->prepare("SELECT * FROM sozlesme_sablonlari WHERE id = :id AND firma_id = :firma_id");
$stmt->execute([':id' => $id, ':firma_id' => $firma_id]);
$sablon = $stmt->fetch();

if (!$sablon) {
    die("Şablon bulunamadı!");
}

// Dosya uzantısını kontrol et (Sadece resimler düzenlenebilir)
$ext = strtolower(pathinfo($sablon['dosya_yolu'], PATHINFO_EXTENSION));
if (!in_array($ext, ['jpg', 'jpeg', 'png'])) {
    die("Bu düzenleyici sadece resim dosyaları (JPG, PNG) için kullanılabilir. PDF desteği ileride eklenecektir.");
}

// Kaydetme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sahalar = $_POST['sahalar'] ?? '[]';

    $update = $db->prepare("UPDATE sozlesme_sablonlari SET sahalar = :sahalar WHERE id = :id");
    $update->execute([':sahalar' => $sahalar, ':id' => $id]);

    header("Location: sablon-duzenle.php?id=$id&saved=1");
    exit;
}

$mevcut_sahalar = $sablon['sahalar'] ? $sablon['sahalar'] : '[]';
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şablon Düzenle</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background: #f0f2f5;
            padding-bottom: 50px;
        }

        .editor-container {
            display: flex;
            gap: 20px;
            margin-top: 20px;
            height: calc(100vh - 100px);
        }

        .toolbox {
            width: 300px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
            flex-shrink: 0;
        }

        .canvas-area {
            flex-grow: 1;
            background: #e9ecef;
            border-radius: 10px;
            position: relative;
            overflow: auto;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 20px;
        }

        .canvas-wrapper {
            position: relative;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            background: white;
        }

        .canvas-wrapper img {
            max-width: 100%;
            display: block;
            pointer-events: none;
            /* Resim sürüklenmesin */
        }

        .field-item {
            padding: 10px;
            margin-bottom: 10px;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            cursor: move;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.2s;
        }

        .field-item:hover {
            background: #e2e6ea;
            border-color: #adb5bd;
        }

        .field-item i {
            color: #667eea;
        }

        .placed-field {
            position: absolute;
            background: rgba(102, 126, 234, 0.2);
            border: 2px solid #667eea;
            color: #1a1a1a;
            padding: 5px;
            cursor: grab;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
            white-space: nowrap;
            overflow: hidden;
            box-sizing: border-box;
            user-select: none;
        }

        .placed-field:active {
            cursor: grabbing;
        }

        .placed-field .remove-btn {
            position: absolute;
            top: -10px;
            right: -10px;
            background: red;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: none;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 10px;
        }

        .placed-field:hover .remove-btn {
            display: flex;
        }

        .resize-handle {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 10px;
            height: 10px;
            background: #667eea;
            cursor: se-resize;
        }

        .category-title {
            font-size: 0.85rem;
            text-transform: uppercase;
            color: #6c757d;
            margin-top: 15px;
            margin-bottom: 10px;
            font-weight: bold;
            border-bottom: 1px solid #dee2e6;
            padding-bottom: 5px;
        }
    </style>
</head>

<body>
    <div class="container-fluid px-4">
        <div class="d-flex justify-content-between align-items-center pt-3">
            <div>
                <h4 class="mb-0">Şablon Düzenleyici: <?php echo htmlspecialchars($sablon['ad']); ?></h4>
                <small class="text-muted">Alanları sürükleyip resmin üzerine bırakın.</small>
            </div>
            <div>
                <a href="sablonlar.php" class="btn btn-outline-secondary me-2">İptal</a>
                <button onclick="saveDesign()" class="btn btn-primary">
                    <i class="bi bi-save"></i> Kaydet
                </button>
            </div>
        </div>

        <?php if (isset($_GET['saved'])): ?>
            <div class="alert alert-success mt-3 py-2">
                <i class="bi bi-check-circle"></i> Değişiklikler kaydedildi.
            </div>
        <?php endif; ?>

        <div class="editor-container">
            <!-- Araç Kutusu -->
            <div class="toolbox">
                <div class="category-title mt-0">Firma Bilgileri</div>
                <div class="field-item" draggable="true" data-type="ticari_unvan" data-label="Ticari Ünvan">
                    <i class="bi bi-building"></i> Ticari Ünvan
                </div>
                <div class="field-item" draggable="true" data-type="firma_adres" data-label="Firma Adresi">
                    <i class="bi bi-geo-alt"></i> Adres
                </div>
                <div class="field-item" draggable="true" data-type="firma_telefon" data-label="Firma Telefon">
                    <i class="bi bi-telephone"></i> Telefon
                </div>
                <div class="field-item" draggable="true" data-type="yetki_belge_no" data-label="Yetki Belge No">
                    <i class="bi bi-award"></i> Yetki Belge No
                </div>
                <div class="field-item" draggable="true" data-type="firma_logo" data-label="Firma Logosu">
                    <i class="bi bi-image"></i> Firma Logosu
                </div>

                <div class="category-title">Danışman Bilgileri</div>
                <div class="field-item" draggable="true" data-type="danisman_ad" data-label="Danışman Adı">
                    <i class="bi bi-person-badge"></i> Ad Soyad
                </div>
                <div class="field-item" draggable="true" data-type="danisman_telefon" data-label="Danışman Tel">
                    <i class="bi bi-phone"></i> Telefon
                </div>

                <div class="category-title">Gayrimenkul Bilgileri</div>
                <div class="field-item" draggable="true" data-type="il" data-label="İl">
                    <i class="bi bi-map"></i> İl
                </div>
                <div class="field-item" draggable="true" data-type="ilce" data-label="İlçe">
                    <i class="bi bi-pin-map"></i> İlçe
                </div>
                <div class="field-item" draggable="true" data-type="mahalle" data-label="Mahalle">
                    <i class="bi bi-geo"></i> Mahalle
                </div>
                <div class="field-item" draggable="true" data-type="ada" data-label="Ada">
                    <i class="bi bi-grid-3x3"></i> Ada
                </div>
                <div class="field-item" draggable="true" data-type="parsel" data-label="Parsel">
                    <i class="bi bi-grid"></i> Parsel
                </div>
                <div class="field-item" draggable="true" data-type="bagimsiz_bolum" data-label="Bağ. Bölüm No">
                    <i class="bi bi-door-open"></i> Bağ. Bölüm No
                </div>
                <div class="field-item" draggable="true" data-type="nitelik" data-label="Niteliği">
                    <i class="bi bi-house"></i> Niteliği
                </div>
                <div class="field-item" draggable="true" data-type="tam_adres" data-label="Açık Adres">
                    <i class="bi bi-signpost-2"></i> Açık Adres
                </div>
                <div class="field-item" draggable="true" data-type="fiyat" data-label="Fiyat">
                    <i class="bi bi-currency-try"></i> Fiyat
                </div>
                <div class="field-item" draggable="true" data-type="hizmet_bedeli" data-label="Hizmet Bedeli">
                    <i class="bi bi-cash-stack"></i> Hizmet Bedeli
                </div>

                <div class="category-title">Müşteri & İmza</div>
                <div class="field-item" draggable="true" data-type="musteri_ad" data-label="Müşteri Adı">
                    <i class="bi bi-person"></i> Müşteri Adı
                </div>
                <div class="field-item" draggable="true" data-type="musteri_tc" data-label="TC Kimlik">
                    <i class="bi bi-card-heading"></i> TC Kimlik
                </div>
                <div class="field-item" draggable="true" data-type="musteri_telefon" data-label="Müşteri Telefon">
                    <i class="bi bi-phone"></i> Müşteri Telefon
                </div>
                <div class="field-item" draggable="true" data-type="musteri_adres" data-label="İletişim Adresi">
                    <i class="bi bi-geo-alt-fill"></i> İletişim Adresi
                </div>
                <div class="field-item" draggable="true" data-type="imza_yer_gosterme" data-label="Yer Gösterme İmzası">
                    <i class="bi bi-pen"></i> İmza (Yer Gösterme)
                </div>
                <div class="field-item" draggable="true" data-type="imza_teyit" data-label="Teyit İmzası">
                    <i class="bi bi-pen-fill"></i> İmza (Teyit)
                </div>

                <div class="category-title">Diğer</div>
                <div class="field-item" draggable="true" data-type="tarih" data-label="Tarih" title="Bugünün Tarihi">
                    <i class="bi bi-calendar-date"></i> Tarih (Otomatik)
                </div>
            </div>

            <!-- Canvas -->
            <div class="canvas-area" id="canvasArea">
                <div class="canvas-wrapper" id="canvasWrapper">
                    <img src="../<?php echo htmlspecialchars($sablon['dosya_yolu']); ?>" id="templateImage">
                    <!-- Alanlar buraya eklenecek -->
                </div>
            </div>
        </div>
    </div>

    <!-- Hidden Form for Saving -->
    <form id="saveForm" method="POST" style="display:none;">
        <input type="hidden" name="sahalar" id="sahalarInput">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Veriler PHP'den geliyor
        const savedFields = <?php echo $mevcut_sahalar; ?>;
        const canvasWrapper = document.getElementById('canvasWrapper');
        const templateImage = document.getElementById('templateImage');

        // Sürükle Bırak İşlemleri
        document.querySelectorAll('.field-item').forEach(item => {
            item.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('type', item.dataset.type);
                e.dataTransfer.setData('label', item.dataset.label);
            });
        });

        canvasWrapper.addEventListener('dragover', (e) => e.preventDefault());

        canvasWrapper.addEventListener('drop', (e) => {
            e.preventDefault();
            const type = e.dataTransfer.getData('type');
            const label = e.dataTransfer.getData('label');

            // Mouse pozisyonunu hesapla (resme göre)
            const rect = canvasWrapper.getBoundingClientRect();
            const x = e.clientX - rect.left - 75; // Ortalama için
            const y = e.clientY - rect.top - 15;

            addFieldToCanvas(type, label, x, y);
        });

        // Alan Ekleme Fonksiyonu
        function addFieldToCanvas(type, label, x, y, width = 150, height = 30) {
            const el = document.createElement('div');
            el.className = 'placed-field';
            el.dataset.type = type;
            el.textContent = label;
            el.style.left = x + 'px';
            el.style.top = y + 'px';
            el.style.width = width + 'px';
            el.style.height = height + 'px';

            // Eğer imza alanıysa daha büyük yap
            if (type.includes('imza')) {
                el.style.height = '60px';
                el.style.width = '100px';
            }

            // Silme butonu
            const removeBtn = document.createElement('div');
            removeBtn.className = 'remove-btn';
            removeBtn.innerHTML = '×';
            removeBtn.onclick = (e) => {
                e.stopPropagation();
                el.remove();
            };
            el.appendChild(removeBtn);

            // Resize handle
            const resizer = document.createElement('div');
            resizer.className = 'resize-handle';
            el.appendChild(resizer);

            // Sürükleme Logic (Canvas içinde)
            let isDragging = false;
            let startX, startY, initialLeft, initialTop;

            el.addEventListener('mousedown', (e) => {
                if (e.target === resizer) return; // Resize ise sürükleme
                isDragging = true;
                startX = e.clientX;
                startY = e.clientY;
                initialLeft = el.offsetLeft;
                initialTop = el.offsetTop;
                el.style.zIndex = 1000;
            });

            // Resize Logic
            let isResizing = false;
            let startW, startH;

            resizer.addEventListener('mousedown', (e) => {
                isResizing = true;
                e.stopPropagation(); // Parent drag tetiklemesin
                startX = e.clientX;
                startY = e.clientY;
                startW = el.offsetWidth;
                startH = el.offsetHeight;
            });

            window.addEventListener('mousemove', (e) => {
                if (isDragging) {
                    const dx = e.clientX - startX;
                    const dy = e.clientY - startY;
                    el.style.left = (initialLeft + dx) + 'px';
                    el.style.top = (initialTop + dy) + 'px';
                }
                if (isResizing) {
                    const dx = e.clientX - startX;
                    const dy = e.clientY - startY;
                    el.style.width = (startW + dx) + 'px';
                    el.style.height = (startH + dy) + 'px';
                }
            });

            window.addEventListener('mouseup', () => {
                isDragging = false;
                isResizing = false;
                el.style.zIndex = '';
            });

            canvasWrapper.appendChild(el);
        }

        // Mevcut alanları yükle
        // Resim yüklendikten sonra çalışmalı ki boyutlar doğru olsun
        templateImage.onload = () => {
            savedFields.forEach(field => {
                // Kaydedilen veriler yüzde cinsindeyse piksele çevirilebilir
                // Şimdilik sistemimiz direk piksel (bu editördeki) veya orijinal resme oranlı çalışmalı
                // Basitlik için: Veritabanına "orijinal resim boyutuna göre" piksel kaydedeceğiz.
                // Ancak editörde resim CSS ile küçültülmüş olabilir (max-width: 100%).
                // Bu yüzden oran kullanmak en sağlıklısı.

                // Şimdilik basit piksel mantığı (Editördeki boyuta göre)
                // Gelişmiş versiyonda oran hesabı yapacağız save aşamasında.

                // Burada "x" ve "y" değerlerinin editördeki görüntülenen resme göre ölçeklenmesi gerekir.
                // Ancak ContractGenerator orijinal resimle çalışıyor.
                // Çözüm: Save ederken orijinal resim boyutuna oranlayıp kaydetmek.
                // Load ederken de tersini yapmak.

                // ŞİMDİLİK: Editörde resmi "doğal boyutuyla" göstermeye çalışalım veya oran hesaplayalım.
                // En doğrusu: Coordinates are stored relative to the ORIGINAL image size.

                const realW = templateImage.naturalWidth;
                const realH = templateImage.naturalHeight;
                const displayW = templateImage.width;
                const displayH = templateImage.height;

                const ratioX = displayW / realW;
                const ratioY = displayH / realH;

                addFieldToCanvas(
                    field.type,
                    field.label,
                    field.x * ratioX,
                    field.y * ratioY,
                    field.w * ratioX,
                    field.h * ratioY
                );
            });
        };

        // Eğer resim zaten önbellekteyse onload tetiklenmeyebilir, manuel çağır
        if (templateImage.complete) templateImage.onload();

        function saveDesign() {
            const fields = [];

            // Orijinal resim boyutları
            const realW = templateImage.naturalWidth;
            const realH = templateImage.naturalHeight;
            // Görüntülenen boyutlar
            const displayW = templateImage.width;
            const displayH = templateImage.height;

            const ratioX = realW / displayW;
            const ratioY = realH / displayH;

            document.querySelectorAll('.placed-field').forEach(el => {
                fields.push({
                    type: el.dataset.type,
                    label: el.textContent.replace('×', '').trim(), // × işaretini temizle
                    // Koordinatları orijinal resim boyutuna çevir
                    x: Math.round(el.offsetLeft * ratioX),
                    y: Math.round(el.offsetTop * ratioY),
                    w: Math.round(el.offsetWidth * ratioX),
                    h: Math.round(el.offsetHeight * ratioY)
                });
            });

            document.getElementById('sahalarInput').value = JSON.stringify(fields);
            document.getElementById('saveForm').submit();
        }
    </script>
</body>

</html>